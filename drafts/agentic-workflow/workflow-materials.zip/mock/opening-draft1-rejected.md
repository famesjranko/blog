# Opening

I work with Claude and Codex through T3, with the agents running on an always-on workbench. I can pick up a session from my laptop or phone, and sometimes talk through what I want using speech-to-text.

The setup follows a distinction I find useful: what needs judgement, and what can be checked mechanically. I give agents room to choose an approach, while code handles requirements such as file-size limits and the structure of task reports. When I use a team, each agent gets a bounded job, and the lead keeps its attention on decisions and whether the work is complete.

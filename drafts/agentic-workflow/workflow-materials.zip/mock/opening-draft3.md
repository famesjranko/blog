# Opening

I’m a solo developer, and coding agents are part of how I build and maintain my projects. I work across different languages and frameworks, and I enjoy experimenting with the tools and with how I organise the work.

I’ve put a lot of thought into the environment the agents work in and how I coordinate and check what they do. This page brings that setup together: my workbench, project foundations, agent teams and the skills I use along the way.

**Approved — revision 21 is ready for content correctness.** No concrete blockers found.

- The Context / Structure / Checks / Custody map matches the conceptual source at [section 4](/home/andy/src/agent-toolkit/research/project-foundation/agentic-project-skill-final-findings.md:191). Its limits and “required CI checks where configured” wording avoid overstating enforcement.
- The catalogue accurately summarises the current skills. `project-init` is explicitly invoked in both runtime declarations: [SKILL.md](/home/andy/src/agent-toolkit/skills/project-init/SKILL.md:4) and [openai.yaml](/home/andy/src/agent-toolkit/skills/project-init/agents/openai.yaml:5).
- The shortened handoff text preserves the distinction between report checks and lead judgment. The local/PR/release strip makes no claim of identical coverage.
- All SVG blocks are identical to approved revision 20. No historical trial narrative or installed `project-foundation` claim was introduced.

Earlier limits remain: live GitHub protection and issue #402’s remote state were not independently verified. No edits, subagents, tests or skill workflows were performed.
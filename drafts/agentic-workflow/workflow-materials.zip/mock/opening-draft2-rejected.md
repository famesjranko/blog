# Opening

I’ve put together a way of working with coding agents that carries across my projects. Each repository supplies its own context and checks, while a shared toolkit provides the skills and coordination rules. My workbench keeps the agents running on dedicated hardware, accessible from my laptop or phone.

The distinction I keep coming back to is where judgement is needed. I give agents room to work out an approach. Where a requirement can be checked in code, I make it part of the checks they have to pass. That applies to the code they write and, when working as a team, how they report their work to each other.

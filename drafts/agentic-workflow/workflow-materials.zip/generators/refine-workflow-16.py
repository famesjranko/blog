from pathlib import Path
p=Path('/tmp/build-workflow-story.py')
s=p.read_text()
def replace(old,new):
 global s
 assert old in s,old[:90]
 s=s.replace(old,new,1)
replace('I bring in lead-team when independent review','I bring in an agent team when independent review')
replace('The <code>investigate</code> skill gives the agent a repeatable process:', 'The <code>investigate</code> skill—a packaged procedure—gives the agent a repeatable process:')
replace('Inspect the combined work and run its full checks.','The agent reviews the change and runs the full checks.')
old='<p class="section-followup">People, agents and CI use the same <code>make check</code> gate. A Makefile gives each repository one command map; its tools return specific failures for the agent to correct.</p>'
replace(old,'')
replace('<div class="commands">','<p>A Makefile gives each repository one command map. People and agents use <code>make check</code> for the full local gate; its tools return specific failures to correct. CI reuses the underlying commands, with any differences made explicit.</p><div class="commands">')
replace('<p>The observer reads the ledger for decisions and native logs for activity. Workers do not maintain a separate dashboard report. A task can be idle in the runtime while still awaiting the lead’s decision.</p>','')
addition='''<h3>Local checks, PR checks and release</h3><p>MusicMeta, my music metadata library, shows how verification continues beyond the workbench. Continuous integration (CI) runs checks on GitHub; publishing and deployment have separate triggers.</p><dl class="tools"><div><dt>On the workbench</dt><dd><code>make check</code> verifies the working copy before it is pushed. The faster <code>make check-fast</code> is for the edit loop and is not enough to approve a change.</dd></div><div><dt>On the pull request</dt><dd>GitHub Actions runs checks from a fresh checkout. The build and demo checks must pass before merge; I review the result.</dd></div><div><dt>Release or deploy</dt><dd>After review, I explicitly start the relevant workflow. Publishing the library and deploying its web demo are separate operations.</dd></div></dl><details><summary>MusicMeta’s checks and release boundaries</summary><p>Locally, <code>make check</code> calls <code>./check</code>. CI runs that script with <code>--skip-demo</code> and compiles and tests the demos in a separate required job. The coverage is not identical: CI’s demo job currently omits lint checks that the local gate runs.</p><p>The release workflow checks version consistency, runs tests and checks the public API, then publishes to Maven Central. It confirms that the packages can be downloaded before creating the tag and GitHub Release. A separate manual workflow builds and deploys the web demo to Cloud Run and checks the service’s reported revision and scaling limits. A passing local check does not establish that either operation succeeded.</p></details>\n'''
replace('<div class="test">',addition+'<div class="test">')
p.write_text(s)
style=Path('/tmp/style-workflow-blog.py')
style.write_text(style.read_text().replace('column-15','column-16'))

from pathlib import Path
p=Path('/home/andy/.t3/artifacts/agentic-workflow-20261009/d-workflow.css');s=p.read_text()
s=s[:s.index('/* This portfolio format')]
s=s.replace('.workflow { --rule: var(--color-border); }', '.workflow { --rule: var(--color-border); max-width: 48rem; margin-inline: auto; }')
s += '''/* One shared column: figures and panels align with the text at every width. */
.workflow .review-check { display: grid; grid-template-columns: repeat(2,minmax(0,1fr)); gap: 1.5rem; margin-block: 1.75rem; }
.workflow .review-check > div { padding-top: 1rem; border-top: 1px solid var(--rule); }
.workflow .review-check h3 { margin: 0 0 .7rem; font: 600 1rem/1.5 var(--font-ui); }
.workflow .review-check p { margin: 0; font-size: 1rem; }
.workflow .observer-flow { display: grid; grid-template-columns: repeat(3,minmax(0,1fr)); gap: 1.5rem; list-style: none; padding: 0; margin: 1.75rem 0; }
.workflow .observer-flow li { position: relative; margin: 0; font: .85rem/1.6 var(--font-ui); }
.workflow .observer-flow li:not(:last-child)::after { content: '→'; position: absolute; right: -1rem; top: .15rem; color: var(--color-accent); }
.workflow .observer-flow strong { display: block; color: var(--color-text); margin-bottom: .3rem; }
.workflow .observer-flow span { color: var(--color-muted); }
.workflow .dashboard-preview svg { width: 100%; border: 1px solid var(--rule); border-radius: .4rem; }
.workflow .dashboard-preview a { display: block; }
.workflow #observer .evidence { margin-top: 1.25rem; }
.workflow #observer .evidence h3 { margin-top: 0; }
.workflow .dashboard-points > div { border-top: 1px solid var(--rule); padding-block: .85rem; }
.workflow .dashboard-points dt { font: 600 .9rem/1.6 var(--font-ui); }
.workflow .dashboard-points dd { margin-top: .3rem; font-size: 1rem; }
@media (max-width: 42rem) {
 .workflow .review-check { grid-template-columns: minmax(0,1fr); gap: 1.25rem; }
 .workflow .observer-flow { grid-template-columns: minmax(0,1fr); gap: 1rem; }
 .workflow .observer-flow li { padding-left: 1rem; border-left: 2px solid var(--rule); }
 .workflow .observer-flow li:not(:last-child)::after { display: none; }
}
'''
p.write_text(s)
p=Path('/tmp/workflow-team-diagram.py');s=p.read_text()
start=s.index('b = node(370,15')
end=s.index("b = node(45,10")
s=s[:start]+'''b = node(20,220,245,105,'Lead','Assign · accept|Send back','primary')
# Assignment trunk is to the left of the roles; reports return around their right.
b += '<path class="wire" d="M265 255 H310 M310 55 V475"/>'
for i,(title,_,sub) in enumerate(roles):
 y = 20 + i*105
 b += node(355,y,315,70,title,sub)
 b += wire(f'M310 {y+35} H355')
 b += f'<path class="wire secondary" d="M670 {y+35} H695"/>'
b += wire('M695 55 V535 H142 V325',dash=True)
b += '<text class="label" x="355" y="575" text-anchor="middle">Solid: lead assigns or sends back.</text><text class="label" x="355" y="602" text-anchor="middle">Dashed: each role reports to the lead.</text>'
team = svg('story-team',715,625,b,'Five task roles report to the lead','Planner, Explorer, Worker, Reviewer and Chore are available task roles. The lead assigns each contract; every role reports back to the lead. The rows are not an execution sequence. Task dependencies are stored separately.')
''' + s[end:]
p.write_text(s)
p=Path('/tmp/build-workflow-story.py');s=p.read_text()
s=s.replace('<a href="#team">The agent team</a><a href="#environment">', '<a href="#team">The agent team</a><a href="#observer">The dashboard</a><a href="#environment">')
start=s.index('<div class="evidence" id="real-run">')
end=s.index('<section id="environment">', start)
old=s[start:end]
assert old.endswith('</section>\n')
evidence=old[:-len('</section>\n')]
# Keep the actual send-back example, with full graph access, as a deeper view.
evidence=evidence.replace('<span class="eyebrow">Evidence · a real run</span>', '')
new='''</section>
<section id="observer"><div class="section-heading"><span class="eyebrow">03 · Observe the team</span><h2>See what is happening, and what needs a decision</h2><p>I built the lead-team observer to make a run inspectable. T3 is where I direct the agents. The observer is a read-only dashboard showing what is running, what is waiting and why work was accepted or sent back.</p></div>
<ol class="observer-flow" aria-label="How the dashboard gets its data"><li><strong>Ledger + runtime logs</strong><span>Task records, decisions and agent activity.</span></li><li><strong>Observer</strong><span>Collects the recorded state and events.</span></li><li><strong>Dashboard + replay</strong><span>Inspect the live run or its saved history.</span></li></ol>
<figure class="dashboard-preview"><a href="team-dashboard.jpg" aria-label="Open the complete team observer screenshot"><svg viewBox="0 0 1200 1150" role="img" aria-labelledby="observer-shot-title observer-shot-desc"><title id="observer-shot-title">The observer’s attention and running-work panels</title><desc id="observer-shot-desc">A portion of the original dashboard screenshot. Needs attention shows final_check waiting for the lead; Running now shows a separate task and its agent activity.</desc><image href="team-dashboard.jpg" width="1200" height="4132"/></svg></a><figcaption>A real run: <code>final_check</code> is waiting for the lead while another task is still running. Open the image to inspect the full dashboard.</figcaption></figure>
<dl class="dashboard-points"><div><dt>Follow the work</dt><dd>The dependency graph shows parallel tasks, waiting work and rework loops. An agent finishing its turn is distinct from the lead accepting its task.</dd></div><div><dt>Inspect the evidence</dt><dd>Select a task to see its contract, acceptance criteria, reported evidence and decision history. The team view shows each agent’s role, model and activity.</dd></div></dl>
<details><summary>Open a real send-back and the task graph</summary>''' + evidence + '''</details>
<details><summary>Where the dashboard’s information comes from</summary><p>The ledger supplies task status and lead decisions; native session logs supply agent activity and available usage counters. Workers do not write a separate dashboard report. Missing information and capture gaps remain visible. Closing the observer saves a single-file replay that opens offline.</p></details></section>
'''
s=s[:start]+new+s[end:]
s=s.replace('03 · Where it runs / Zoom 0','04 · Where it runs / Zoom 0').replace('04 · Inside “Review + check”','05 · Inside “Review + check”')
p.write_text(s)
p=Path('/tmp/style-workflow-blog.py');s=p.read_text().replace('d-workflow.css?style=blog-2','d-workflow.css?style=column-12');p.write_text(s)
p=Path('/home/andy/.t3/artifacts/agentic-workflow-20261009/sources.html');s=p.read_text()
new='''<h2>Consistent column and observer dashboard</h2><p>Andy’s revision-11 screenshot showed the repeated changes in width between paragraphs, figures and panels. This revision removes those exceptions and gives all article content one 48rem maximum column, with the existing responsive gutters and reading font. The team role map is redrawn for that column, with the lead beside five independent task roles on desktop and separate assignment/report rails on mobile. It does not turn the role list into an execution sequence.</p><p>The observer now has its own visible section, separated from T3’s control interface. Sources: current docs/lead-team.md §9, skills/lead-team/references/observation.md, and the supplied dashboard screenshot. It is read-only; task contracts/status/decisions come from the ledger, activity and available usage come from native logs, and capture gaps remain explicit. Offline replay is a saved record, not resumed execution. The top screenshot viewport shows the original attention and running panels without changing the source image; the previous graph/send-back example remains expandable. No fabricated dashboard state is used.</p>'''
s=s.replace('<h2>Deliberate editorial choices</h2>',new+'<h2>Deliberate editorial choices</h2>');p.write_text(s)

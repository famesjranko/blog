from pathlib import Path
from html import escape
import re
root=Path('/home/andy/.t3/artifacts/agentic-workflow-20261009')
base=(root/'d-workflow.html').read_text()
a=[
'I tend to have a few projects on the go, often in different languages and frameworks. Claude and Codex are now part of how I work on them, and I’ve spent quite a bit of time building a setup I can use across those projects.',
'The distinction I keep coming back to is between judgement and mechanics. Agents need room to work through a problem. Where a rule can be checked in code, I make it part of the workflow so it doesn’t depend on an agent remembering it.'
]
b=[
'Working with coding agents has made me think more carefully about what needs judgement and what can be checked in code. I want agents to have room to solve a problem, with routine rules built into the tools they use.',
'That’s the approach behind my setup. I’ve built a toolkit around Claude and Codex, including a way to coordinate teams and follow their work. I use it across projects, with the checks adapted to each repository.'
]
practice='''<h3>Checks that fit the project</h3><p>Each project has its own requirements, so I choose its type checks, lint rules and complexity limits accordingly. A few preferences carry across repositories, including limits on file and function length.</p><p>The commands still live in a Makefile. <code>make format</code> applies the project’s formatting; <code>make check</code> runs the checks defined for that repository. On this blog, that includes formatting, linting, type checking, structural rules, tests and the site build.</p>'''
def paragraphs(items):return ''.join('<p>'+escape(p)+'</p>' for p in items)
body=f'''<div class="hero"><span class="eyebrow">Working copy · voice study</span><h1>Finding the opening</h1><p>Two short directions for the introduction, followed by the revised explanation of project checks. The current draft remains unchanged.</p></div><nav aria-label="On this page"><a href="#projects">A · Projects</a><a href="#approach">B · Approach</a><a href="#checks">Project checks</a></nav><section id="projects"><span class="eyebrow">A · Start with the projects · recommended</span><h2>How I work as a solo developer</h2>{paragraphs(a)}</section><section id="approach"><span class="eyebrow">B · Start with the approach</span><h2>How I work as a solo developer</h2>{paragraphs(b)}</section><section id="checks"><span class="eyebrow">Shared revision · practices</span>{practice}</section><p class="draft-tools"><a href="d-workflow.html?revision=20">Read the current draft</a> · <a href="https://mattbalshaw.com/agentic-engineering">Matt’s article</a></p>'''
html,n=re.subn(r'(<article class="prose essay workflow">).*?(</article>)',lambda m:m.group(1)+body+m.group(2),base,flags=re.S)
assert n==1
html=html.replace('<title>How I work as a solo developer — Andrew J. McDonald</title>','<title>Workflow opening — voice study</title>')
(root/'voice-study.html').write_text(html)
print('Wrote voice-study.html; revision20 unchanged.')

from pathlib import Path
from html import escape
p=Path('/home/andy/.t3/artifacts/agentic-workflow-20261009')

def node(x,y,w,h,title,sub='',kind='node'):
    a=f'<rect class="{kind}" x="{x}" y="{y}" width="{w}" height="{h}" rx="10"/>'
    a+=f'<text class="heading" x="{x+w/2}" y="{y+30}" text-anchor="middle">{escape(title)}</text>'
    for i,line in enumerate(sub.split('|') if sub else []):a+=f'<text class="muted" x="{x+w/2}" y="{y+54+i*21}" text-anchor="middle">{escape(line)}</text>'
    return a

def box(x,y,w,h,title,sub=''):
    return f'<rect class="boundary" x="{x}" y="{y}" width="{w}" height="{h}" rx="14"/><text class="boundary-title" x="{x+20}" y="{y+29}">{escape(title)}</text>'+ (f'<text class="muted" x="{x+20}" y="{y+51}">{escape(sub)}</text>' if sub else '')

def wire(d,label='',x=0,y=0,dash=False):
    return f'<path class="wire {"secondary" if dash else ""}" d="{d}" marker-end="url(#ARROW)"/>'+ (f'<text class="label" x="{x}" y="{y}" text-anchor="middle">{escape(label)}</text>' if label else '')

def svg(id,w,h,body,title,desc):
    return f'<svg class="diagram" viewBox="0 0 {w} {h}" role="img" aria-labelledby="{id}-title {id}-desc"><title id="{id}-title">{escape(title)}</title><desc id="{id}-desc">{escape(desc)}</desc><defs><marker id="{id}-arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto-start-reverse"><path class="arrowhead" d="M0 0 L8 4 L0 8 Z"/></marker></defs>{body.replace("#ARROW",f"#{id}-arrow")}</svg>'

# V0: the context, with only five concepts.
b=node(20,130,180,86,'Me','Laptop or phone')
b+=node(280,100,270,140,'AI workbench','T3 interface · coding agents|Projects and development tools','primary')
b+=node(700,25,240,86,'Hosted AI models','Reasoning and code generation')
b+=node(700,245,240,86,'Test lab','Temporary machines + storage')
b+=wire('M200 172 H280','Tailscale',240,150)
b+=wire('M550 140 H625 V68 H700','API requests',625,45)
b+=wire('M550 200 H625 V288 H700','Create · test · release',628,350)
b+=node(700,405,240,86,'Cloud services','Logs, analytics + test builds')+wire('M550 225 H580 V448 H700')
overview=svg('context',970,520,b,'V0: the whole environment','I reach the permanent workbench privately through Tailscale. The workbench uses hosted models and requests temporary test environments.')
b=node(80,10,270,86,'Me','Laptop or phone')+node(65,160,300,130,'AI workbench','T3 · coding agents · projects','primary')+node(65,365,300,86,'Hosted AI models','Reasoning and code generation')+node(65,525,300,86,'Test lab','Temporary machines + storage')
b+=wire('M215 96 V160','Tailscale',280,134)+wire('M215 290 V365','API requests',284,340)+wire('M65 225 H25 V568 H65','',0,0)+ '<text class="label" x="215" y="510" text-anchor="middle">Create · test · release</text>'
b+=node(65,685,300,86,'Cloud services','Logs, analytics + test builds')+wire('M25 568 V728 H65')
overview_m=svg('context-mobile',430,800,b,'V0: the whole environment','Private access to a workbench that connects to hosted models and an on-demand test lab.')

# V1: deployment boundaries, data and control paths.
b=box(20,140,770,510,'PROXMOX HOST','Runs the permanent workbench and disposable guests')
b+=box(45,215,430,390,'Permanent workbench VM · Debian')
b+=node(65,280,170,76,'T3 Code','Browser interface','primary')
b+=node(65,405,170,95,'Claude / Codex','Coding clients|Git worktrees + tools','primary')
b+=node(285,280,160,76,'llmtrim','Local request proxy')
b+=node(285,505,160,76,'lab-control','MCP tools','primary')
b+=node(530,255,230,86,'Proxmox API','Create / remove guests')
b+=node(530,465,230,110,'Disposable VM','Debian test environment|Isolated lab network')
b+=node(855,250,240,95,'Hosted models','Model APIs|Outside the homelab')
b+=node(855,465,240,110,'TrueNAS','Temporary datasets|Shared files over NFS')
b+=node(20,15,215,86,'Laptop / phone','Browser')+node(315,15,210,86,'Tailscale','Private remote access')
b+=wire('M235 58 H315')+wire('M420 101 V122 H5 V318 H65')
b+=wire('M150 356 V405','launch',196,388)
b+=wire('M235 440 H260 V318 H285')
b+=wire('M365 280 V202 H975 V250','model requests',880,176)
b+=wire('M235 475 H258 V543 H285','MCP tools',225,531)
b+=wire('M365 505 V375 H645 V341','manage guests',560,363)
b+=wire('M645 341 V465','provision',692,417)
b+=wire('M235 455 H500 V520 H530','SSH: run tests',427,443)
b+=wire('M365 581 V625 H975 V575','storage API: create / clean up',771,615,True)
b+=wire('M855 525 H760','NFS files',808,510,True)
deployment=svg('deployment',1120,680,b,'V1: workbench and lab infrastructure','Tailscale reaches T3 inside a Debian workbench on Proxmox. T3 launches coding clients. Model requests go through llmtrim to hosted providers. Agents request lab-control through MCP. The gateway manages Proxmox guests and TrueNAS datasets. Agents use SSH to run tests in a guest; the guest mounts its temporary files from TrueNAS over NFS.')
b=node(65,10,300,80,'Laptop / phone','Browser')+node(65,145,300,80,'Tailscale','Private remote access')
b+=box(10,275,410,670,'PROXMOX HOST')+box(30,330,370,365,'Permanent workbench VM')
b+=node(65,390,300,70,'T3 Code','Browser interface','primary')+node(65,505,300,70,'Claude Code / Codex','Git worktrees + project tools','primary')+node(65,620,300,60,'lab-control','Proxmox + TrueNAS MCP')
b+=node(65,780,300,130,'Disposable VM','Proxmox API creates the guest|Agents run tests over SSH|Guest stays on the lab network')
b+=node(65,1020,300,100,'TrueNAS','Temporary dataset|Files mounted over NFS')
b+=wire('M215 90 V145')+wire('M215 225 V390')+wire('M215 460 V505')+wire('M215 575 V620','MCP',264,605)+wire('M215 680 V780','create / release',290,739)+wire('M215 1020 V910','NFS files',273,984,True)
b+='<text class="label" x="215" y="1170" text-anchor="middle">Model requests: agents → llmtrim → hosted AI</text><text class="muted" x="215" y="1200" text-anchor="middle">lab-control also creates and cleans up storage.</text>'
deployment_m=svg('deployment-mobile',430,1225,b,'V1: infrastructure, mobile view','The Proxmox host contains the workbench and a separate disposable guest. TrueNAS provides storage outside that host. The workbench reaches model providers through llmtrim.')

# V2: delegation, with state and observation visibly outside execution.
b=node(385,15,260,76,'Me','Goal + final merge decision')+node(385,145,260,76,'Lead agent','Plans, delegates, accepts','primary')
b+=node(30,315,220,86,'Planner','Breaks down the goal')+node(355,315,320,86,'Workers','Build in separate Git worktrees','primary')+node(780,315,220,86,'Reviewer','Checks the combined result')
b+=wire('M515 91 V145')+wire('M450 221 V270 H140 V315')+wire('M515 221 V315')+wire('M580 221 V270 H890 V315')
b+=box(25,460,670,140,'Contracts + task ledger','Scope · file ownership · dependencies · acceptance evidence')
b+='<text class="muted" x="45" y="551">Hooks check task starts, reports and file ownership.</text>'
b+=node(780,480,220,105,'Observer','Task state + activity|Live view and replay')
b+=wire('M515 401 V460','reports + decisions',620,442,True)+wire('M695 530 H780')
team=svg('team',1030,635,b,'V2: how the agents coordinate','I set the goal. A lead delegates to a planner, workers and reviewer. Workers use separate worktrees. Contracts and a task ledger hold decisions; hooks check the workflow. An observer combines task state with native activity logs. I retain the final merge decision.')
b=node(65,10,300,70,'Me','Goal + merge decision')+node(65,130,300,76,'Lead agent','Delegates and accepts','primary')+node(65,260,300,70,'Planner','Divides the work')+node(65,380,300,76,'Workers','Separate Git worktrees','primary')+node(65,510,300,76,'Reviewer','Checks the combined work')+node(40,670,350,105,'Contracts + task ledger','Scope · evidence · decisions|Hooks check the workflow')+node(65,835,300,86,'Observer','Task record + activity logs')
b+=wire('M215 80 V130')+wire('M215 206 V260')+wire('M215 330 V380')+wire('M215 456 V510')+wire('M215 586 V670','reports + decisions',293,638,True)+wire('M215 775 V835')
team_m=svg('team-mobile',430,950,b,'V2: the agent team','A lead coordinates planning, implementation and review. The task ledger records acceptance, and the observer shows the run.')

# V3: rework is a visible edge; passing checks does not merge code.
b=node(20,55,195,85,'Brief','Scope + acceptance')+node(285,55,195,85,'Build','Isolated worktree','primary')+node(550,55,195,85,'Verify','Tests + review')+node(815,55,195,85,'Accept','Lead inspects evidence')
b+=wire('M215 97 H285')+wire('M480 97 H550')+wire('M745 97 H815')+wire('M650 140 V220 H380 V140','Needs correction: send back with a reason',515,255,True)
b+=node(815,320,195,85,'My review','Approve the merge')+wire('M912 140 V320','combined checks pass',894,275)
flow=svg('flow',1040,435,b,'V3: the life of a change','A brief becomes implementation and verification. Failed checks or review return work for correction. The lead accepts evidence. The combined change passes its checks before I decide whether to merge.')
b=node(65,10,300,76,'Brief','Scope + acceptance')+node(65,140,300,76,'Build','Isolated worktree','primary')+node(65,270,300,76,'Verify','Tests + review')+node(65,440,300,76,'Accept','Lead inspects evidence')+node(65,590,300,76,'My review','Approve the merge')
b+=wire('M215 86 V140')+wire('M215 216 V270')+wire('M215 346 V440')+wire('M215 516 V590')+wire('M65 308 H25 V178 H65','',0,0,True)
b+='<text class="label" x="215" y="399" text-anchor="middle">Correction? Return to the worker.</text><text class="label" x="215" y="563" text-anchor="middle">Combined checks pass</text>'
flow_m=svg('flow-mobile',430,700,b,'V3: one task','Brief, build, verify, accept and human review, with a return path for corrections.')

# The team has its own context view, separate from the infrastructure scale.
b=node(20,105,230,95,'My goal','Outcome + constraints')+node(360,80,285,145,'lead-team','Agents coordinate the work|Code checks the process','primary')+node(755,105,255,95,'Reviewed result','Evidence for my decision')
b+=wire('M250 152 H360')+wire('M645 152 H755')
team_context=svg('team-context',1040,270,b,'Team V0: goal to reviewed result','I give a goal and constraints to the team workflow. It returns an integrated result and evidence for my review. Agents judge the work while code checks mechanical rules.')
b=node(65,10,300,90,'My goal','Outcome + constraints')+node(65,165,300,120,'lead-team','Agents coordinate the work|Code checks the process','primary')+node(65,350,300,90,'Reviewed result','Evidence for my decision')
b+=wire('M215 100 V165')+wire('M215 285 V350')
team_context_m=svg('team-context-mobile',430,470,b,'Team V0: goal to reviewed result','A goal enters the team workflow. A reviewed result and its evidence return to me.')

# V1: a task graph below a decision-focused lead, not a fixed organisation chart.
b=node(365,15,350,100,'Lead / main thread','Goal, decisions and acceptance|Keeps the overall context','primary')
b+=node(20,250,220,95,'Plan','Stronger model|Small, scoped tasks')
b+=node(345,190,300,95,'Implement A','Mid-tier model|Own files + relevant context','primary')
b+=node(345,370,300,95,'Implement B','Mid-tier model|Own files + relevant context','primary')
b+=node(775,270,280,95,'Review','Stronger model|Independent judgement')
b+=node(775,490,280,95,'Run the checks','Smaller model|Execute named commands')
b+=wire('M420 115 V150 H130 V250','briefs',270,140)
b+=wire('M240 297 H290 V237 H345')+wire('M240 297 H290 V417 H345')
b+=wire('M645 237 H715 V300 H775')+wire('M645 417 H740 V335 H775')
b+=wire('M915 365 V490','accepted review',977,433)
b+=wire('M1055 535 H1100 V65 H715','evidence for acceptance',910,45)
b+=wire('M775 350 H695 V450 H645','rework',687,486,True)
b+='<text class="label" x="380" y="557" text-anchor="middle">Each node: one responsibility, a bounded brief, evidence back.</text><text class="muted" x="380" y="586" text-anchor="middle">The lead chooses the graph for the task; this is one example.</text>'
team=svg('team',1130,635,b,'Team V1: bounded tasks beneath a decision-focused lead','The lead holds the goal, decisions and acceptance. A planner scopes the work; two workers receive only their relevant context and files. Independent review and mechanical checks follow. Evidence returns to the lead. Review can send work back. Model size follows the judgement needed at each node.')
b=node(40,10,350,105,'Lead / main thread','Goal, decisions and acceptance|Keeps overall context','primary')
b+=node(65,180,300,85,'Plan','Stronger model · scoped tasks')
b+=node(40,345,165,125,'Implement A','Mid-tier model|Own files|Task context','primary')+node(225,345,165,125,'Implement B','Mid-tier model|Own files|Task context','primary')
b+=node(65,555,300,85,'Review','Stronger model · judgement')+node(65,725,300,85,'Run checks','Smaller model · named commands')
b+=wire('M215 115 V180')+wire('M215 265 V305 H122 V345')+wire('M215 305 H307 V345')+wire('M122 470 V510 H215 V555')+wire('M307 470 V510 H215')+wire('M215 640 V725')
b+=wire('M65 600 H15 V407 H40',dash=True)+wire('M365 767 H410 V63 H390')
b+='<text class="label" x="215" y="695" text-anchor="middle">Review can send work back.</text><text class="label" x="215" y="863" text-anchor="middle">Evidence returns to the lead for acceptance.</text>'
team_m=svg('team-mobile',430,895,b,'Team V1: task graph on mobile','Planning branches into independent worker tasks, then converges on review and checks. The lead stays responsible for decisions. Workers hold only their task context.')

# V2: the central design separation, paired at each handoff.
judgements=[('Define the task','One responsibility; relevant context'),('Assign the work','Choose a role and model'),('Build and review','Interpret results; find defects'),('Accept or send back','Judge whether the goal is met')]
mechanisms=[('Validate the contract','Scope, files, checks and dependencies'),('Check the handoff','Spawn hook matches the contract'),('Run checks','Tests, report shape, file ownership'),('Record the decision','Ledger state gates dependent work')]
b=box(20,20,480,650,'JUDGEMENT · AGENTS','Decisions that depend on context')+box(620,20,480,650,'MECHANICAL · CODE','Repeatable checks and state changes')
for i,((title,sub),(code,csub)) in enumerate(zip(judgements,mechanisms)):
 y=125+i*135
 b+=node(65,y,390,85,title,sub,'primary')+node(665,y,390,85,code,csub)+wire(f'M455 {y+42} H665')
 if i<3:b+=wire(f'M665 {y+72} H570 V{y+117} H260 V{y+135}',dash=True)
b+=node(355,735,410,86,'Observer dashboard','Reads the ledger and activity logs')+wire('M860 615 V702 H560 V735')
mechanism=svg('mechanism',1120,850,b,'Team V2: judgement and mechanical enforcement','Agents define tasks, assign work, interpret evidence and decide acceptance. Code validates contracts, gates spawns, runs tests, checks reports and records decisions. The ledger gates dependent work. The dashboard reads the ledger and activity logs; it does not decide whether the work is correct.')
b=''
for i,((title,sub),(code,csub)) in enumerate(zip(judgements,mechanisms)):
 y=15+i*285
 b+=node(35,y,360,95,title,'Agent judgement|'+sub,'primary')
 b+=node(35,y+140,360,95,code,'Code|'+csub)
 b+=wire(f'M215 {y+95} V{y+140}')
 if i<3:b+=wire(f'M215 {y+235} V{y+285}',dash=True)
b+=node(35,1180,360,86,'Observer dashboard','Reads task state and activity')+wire('M215 1105 V1180')
mechanism_m=svg('mechanism-mobile',430,1300,b,'Team V2: judgement and code','Each agent decision is followed by a mechanical check or recorded state change. Code checks the process; agents judge the meaning of the evidence.')

# Expand the agent handoff into the actual schema / hook / acceptance path.
b=node(25,80,255,105,'Lead defines the task','Goal + bounded context|Files + acceptance criteria','primary')
b+=node(370,80,330,105,'Schema validation','Required fields and types|Reject an invalid contract')
b+=node(810,80,280,105,'Stored contract','Typed task in the ledger')
b+=wire('M280 132 H370')+wire('M700 132 H810')
b+=wire('M535 80 V35 H150 V80','invalid → correct the contract',350,23,True)
b+=node(400,245,300,85,'Spawn hook','Contract, dependencies, model')
b+=wire('M950 185 V287 H700')+wire('M400 287 H155 V395')
b+=node(25,395,260,110,'Worker','Fresh, scoped brief|Does the work and checks','primary')
b+=node(370,385,330,145,'Structured report','Status · changes|Evidence for each criterion|Unfinished work · decisions')
b+=node(810,385,280,145,'Report hook','Fields · criterion IDs|Verification commands|Changed-file ownership')
b+=wire('M285 448 H370')+wire('M700 448 H810')
b+=wire('M950 530 V585 H155 V505','invalid → correct the work or report',470,573,True)
b+=node(810,675,280,105,'Lead reviews evidence','Accept or send back|Read the work as well','primary')
b+=node(370,675,330,105,'Ledger records decision','Accepted work unlocks dependencies|Reasons stay on record')
b+=wire('M1035 530 V675','reported ≠ accepted',950,647)+wire('M810 727 H700')
mechanism=svg('mechanism',1120,810,b,'Team V2: enforced contracts between agents','The lead writes a task contract. Code validates its schema and types. A spawn hook checks the contract, dependencies and model before the worker starts with a fresh scoped brief. The worker returns a structured report. The report hook checks fields, criteria, quoted commands and file ownership. An invalid report takes a correction path; unresolved problems are retained for the lead. Reporting is separate from acceptance. The lead judges the work and evidence, and the ledger records the decision.')
b=''
items=[('Lead defines the task','Goal, files and acceptance','primary'),('Schema validation','Required fields and types','node'),('Spawn hook','Contract, dependencies, model','node'),('Worker','Fresh, scoped context','primary'),('Structured report','Status · changes · evidence|Unfinished work · decisions','node'),('Report hook','Fields, criteria and commands|Check changed-file ownership','node'),('Lead reviews evidence','Accept or send back','primary'),('Ledger records decision','Unlock accepted dependencies','node')]
for i,(title,sub,kind) in enumerate(items):
 y=15+i*145;b+=node(45,y,345,105,title,sub,kind)
 if i<7:b+=wire(f'M217 {y+105} V{y+145}')
b+=wire('M45 212 H15 V67 H45',dash=True)+wire('M45 792 H15 V502 H45',dash=True)
b+='<text class="label" x="215" y="1190" text-anchor="middle">Invalid records return for correction.</text><text class="muted" x="215" y="1220" text-anchor="middle">A reported task still needs the lead’s acceptance.</text>'
mechanism_m=svg('mechanism-mobile',430,1250,b,'Team V2: enforced handoffs, mobile view','Typed contracts and hooks check each handoff. Invalid records return for correction or leave visible problems for the lead. The lead separately judges the result before acceptance.')

# Environment V2: expand the lab into a bounded lifecycle.
b=node(20,70,220,95,'Agent request','CPU, memory, storage|Time limit')+node(330,70,330,95,'lab-control MCP','Check capacity and policy|Record a lease')
b+=node(760,15,310,85,'Proxmox','Create a Debian guest')+node(760,205,310,85,'TrueNAS','Create temporary storage')
b+=wire('M240 117 H330','lab_create',285,98)+wire('M660 95 H710 V57 H760')+wire('M660 140 H710 V247 H760')
b+=node(760,390,310,95,'Run the test','Agent → guest over SSH|Guest → files over NFS','primary')
b+=wire('M1070 57 H1100 V437 H1070')+wire('M915 290 V390')
b+=node(330,390,330,95,'Release the lease','Verify ownership|Remove guest and storage')+wire('M760 437 H660')
b+='<text class="label" x="485" y="550" text-anchor="middle">A partial failure is recorded for investigation.</text>'
lab=svg('lab',1130,585,b,'Environment V2: disposable lab lifecycle','An agent requests a bounded lease. lab-control checks policy and capacity, records ownership, creates a Proxmox guest and optional TrueNAS storage. The agent tests over SSH and uses NFS files. Release verifies ownership before cleanup. Partial failures are recorded.')
b=''
items=[('Agent request','Machine size + expiry'),('lab-control MCP','Proxmox + TrueNAS tools'),('Proxmox + TrueNAS','Create guest + optional storage'),('Run the test','SSH into guest; mount NFS files'),('Release','Check ownership; clean up')]
for i,(title,sub) in enumerate(items):
 y=15+i*145;b+=node(35,y,360,95,title,sub,'primary' if i in [0,3] else 'node')
 if i<4:b+=wire(f'M215 {y+95} V{y+145}')
lab_m=svg('lab-mobile',430,725,b,'Environment V2: lab lifecycle','Request, validate, provision, test and release. Partial failures stay on record for investigation.')


# Concrete mechanisms stay beside the relevant zoom level, with code available on demand.
import json
sample=json.loads((p/'contract-example-check.json').read_text())
contract_json=escape(json.dumps(sample['contract'],indent=2))
report_text=escape(sample['report'])
rejection='EVIDENCE does not address acceptance criteria A2: write each id at the start of its evidence line, such as `A2: <command> -> <output>`'
role_detail='''<details class="deep"><summary>Why these roles and context boundaries?</summary><div class="role-grid"><div><h3>Lead</h3><p>Keeps the goal, decisions and integration. Delegates implementation and checks so their detail does not fill its context.</p></div><div><h3>Planner · stronger model</h3><p>Reads the problem and proposes small slices, dependencies and acceptance criteria. The lead judges the plan.</p></div><div><h3>Explorer · mid-tier model</h3><p>Investigates one question without changing files. Several explorers can review through different lenses.</p></div><div><h3>Worker · mid-tier model</h3><p>Builds one slice in its own Git worktree. Separate file ownership permits parallel work; shared files require a sequence.</p></div><div><h3>Reviewer · stronger model</h3><p>Independently inspects the integrated result. A test must show that it fails when the behaviour it protects is removed.</p></div><div><h3>Chore · smallest model</h3><p>Runs named checks and returns output. Code executes the checks; the agent handles the tools and reports what happened.</p></div></div><p class="detail-note">Every task starts with a fresh agent and its contract, without the lead’s conversation history. Model and effort are recorded and checked at spawn. No member exceeds the lead’s tier.</p></details>'''
handoff_detail=f'''<div class="handoff-detail"><div class="detail-intro"><span class="kicker">Inside one handoff</span><h3>“Done” needs evidence attached to the task.</h3><p>This small example uses the real contract fields and validator. The check output is illustrative.</p></div><div class="handoff-pair"><article><span class="kicker">1 · The lead sets the contract</span><dl><dt>Identity</dt><dd><code>id: final_check</code> · <code>parent: lead</code></dd><dt>Responsibility</dt><dd><code>role: Chore</code> · Verify the integrated change.</dd><dt>Acceptance</dt><dd><code>A1</code> The full check command passes.<br><code>A2</code> Record the commit that was checked.</dd><dt>Execution</dt><dd><code>model: haiku</code> · <code>effort: medium</code><br><code>verify: ["make check"]</code></dd></dl><details><summary>View the complete JSON contract</summary><pre>{contract_json}</pre></details></article><article><span class="kicker">2 · The agent returns a report</span><pre>{report_text}</pre><p>Every report carries these five fields. Here, <code>A1</code> has evidence but <code>A2</code> is missing. A success status does not hide that gap.</p></article></div><div class="rejection"><span class="kicker">3 · The hook identifies the missing evidence</span><blockquote>{escape(rejection)}</blockquote><p>The normal stop hook blocks once and asks for a correction. If the report still has problems, or the runtime has already ended the agent, the ledger preserves them for the lead.</p></div><div class="acceptance"><span class="kicker">4 · The lead decides whether to accept</span><p>Adding an <code>A2</code> line satisfies the format check. The lead still checks that the commands ran against the right commit and that the evidence supports the claim.</p><div class="state-track" aria-label="Task states"><span>queued</span><i>→</i><span>running</span><i>→</i><span>reported</span><i>→</i><span>done <small>(accepted)</small></span></div><p>Only acceptance unlocks dependent tasks. A send-back records a reason and returns work for correction.</p></div><details class="deep"><summary>What the contract, hooks and ledger actually enforce</summary><dl class="rules-list"><dt>At registration</dt><dd>Unknown fields, missing fields and wrong types are rejected. Each acceptance criterion needs a unique ID. Workers also need an absolute worktree path, a base revision, owned files and verification commands.</dd><dt>At spawn</dt><dd>The task ID must match a queued contract. Its parent must own the delegation, its dependencies must be accepted, and its model and effort must match. The runtime agent ID is bound to the task; the hook supplies its contract.</dd><dt>At reporting</dt><dd>The report needs the expected labels and status. Evidence must address the criterion IDs and quote the required checks. A Worker’s changed files are compared with its ownership and forbidden-file lists.</dd><dt>At acceptance</dt><dd>The lead records an evidence note. The ledger keeps the decision separately from the agent’s status and preserves any unresolved report problems.</dd><dt>Across the run</dt><dd>A locked, atomic state file holds the current task graph; an append-only journal records commands. The observer combines this record with native activity logs. Workers do not maintain a second progress report.</dd></dl><p class="detail-note">Hooks check structure and workflow. They cannot prove a claim is true, and they are not a security sandbox. Reading the diff and judging the evidence remain the lead’s work.</p></details><details class="deep"><summary>How the graph handles wrong assumptions, rework and escalation</summary><dl class="rules-list"><dt>A claim proves false</dt><dd>An agent can report <code>REJECTED</code> with evidence. The lead can accept that finding and drop tasks that depended on the proposed change.</dd><dt>Work needs correction</dt><dd>The lead sends the task back with a reason. Rework on accepted work becomes a new task; queued dependants are revised to wait for it.</dd><dt>The same failure repeats</dt><dd>A fresh agent receives a short handoff. If the failure needs better judgement, the replacement moves up a model tier within the lead’s limit.</dd><dt>The result is integrated</dt><dd>Accepted branches join one integration branch. Independent review checks the combined work; a Chore runs the final suite on that version. My review governs the final merge.</dd></dl></details></div>'''
mcp_detail='''<div class="detail-intro"><h3>Proxmox and TrueNAS, exposed through MCP</h3><p>MCP is the tool interface the agents call. One <code>lab-control</code> gateway turns those requests into Proxmox machine operations and TrueNAS storage operations.</p></div><div class="mcp-tools"><div><code>lab_status · lab_list</code><p>Check capacity and existing leases before creating anything.</p></div><div><code>lab_create · lab_get</code><p>Request a machine, optional NFS storage or GPU. Receive its lease ID, address, expiry and verified SSH host key.</p></div><div><code>lab_extend · lab_release</code><p>Extend within the lifetime limit, or release the owned machine and storage.</p></div></div><details class="deep"><summary>Why the gateway owns these operations</summary><p>Appliance credentials stay in the gateway service. Code checks resource limits and records a lease in SQLite before provisioning. Deletion requires matching ownership records on the machine and dataset. A mismatch is quarantined; if TrueNAS is off, storage cleanup stays pending.</p><p>The workbench and rootless Docker handle ordinary development. A disposable VM is for a fresh operating system, stronger isolation, kernel behaviour or GPU passthrough. Results must be copied out before release.</p></details>'''

hook_detail = '''<section class="hook-catalog" id="team-hooks"><div class="detail-intro"><span class="kicker">Six lifecycle hooks</span><h3>Rules that run when an agent acts</h3><p>A hook is code called by the agent runtime at a defined event. These six handlers connect the conversation to the task ledger.</p></div><div class="hook-grid"><article><code>spawn</code><h4>Before delegation</h4><p>Requires a queued contract, accepted dependencies and the assigned model and effort. Checks who may delegate; Codex must start without inherited history.</p><span>Why: work starts with an agreed scope and a fresh context.</span></article><article><code>start</code><h4>When the agent starts</h4><p>Binds the runtime’s agent ID to its task and records it as running. The contract reaches the agent through the runtime’s spawn or start hook.</p><span>Why: the brief, worker and later report refer to the same task.</span></article><article><code>edit</code><h4>Before a file edit</h4><p>Rejects a lead’s repository edits through the covered editing tools and directs it to register a Worker task.</p><span>Why: “one quick fix” must not consume the lead’s decision context.</span></article><article><code>message</code><h4>Before more work is sent</h4><p>Allows task messages while running. A reported task needs a recorded send-back first; completed or replaced agents cannot quietly take a new task.</p><span>Why: rework remains visible, and old context does not become a second job.</span></article><article><code>shell</code><h4>Before a shell command</h4><p>Rejects a lead’s polling sleeps: a sleep in a loop or one longer than five seconds. The lead waits for completion; a Chore handles long external waits.</p><span>Why: waiting does not fill the coordination thread with repeated checks.</span></article><article><code>stop</code><h4>Before the agent finishes</h4><p>Checks report fields, criterion IDs and quoted verification commands. For Workers, it also checks changed files against owned and forbidden paths.</p><span>Why: “done” arrives with a record the lead can inspect.</span></article></div><p class="detail-note">One shared implementation is registered for Claude and Codex. Team startup checks for the core spawn, start and stop registrations. Hooks can have runtime gaps; repository checks and review remain separate layers.</p></section>'''
# External systems are separate from the homelab deployment boundary.
b=node(20,145,245,105,'Workbench agents','Code + operational tools','primary')
b+=node(375,30,250,100,'Google Cloud SDK','gcloud · gsutil · bq|Project pinned per command')
b+=node(375,285,250,100,'Cloudflare MCP','Scoped account / zone access|Read by default')
b+=node(770,30,260,100,'Google Cloud','Production logs + state|Authorised test deployments')
b+=node(770,285,260,100,'Cloudflare','Traffic analytics|DNS + configuration')
b+=wire('M265 175 H320 V80 H375')+wire('M265 220 H320 V335 H375')
b+=wire('M625 80 H770','CLI / APIs',697,60)+wire('M625 335 H770','MCP / APIs',697,315)
cloud=svg('cloud-tools',1060,415,b,'Workbench connections to Google Cloud and Cloudflare','Agents use the Google Cloud command-line tools with a pinned project for logs, resource inspection and authorised test deployments. Cloudflare MCP supplies scoped access to analytics and configuration. Cloudflare preview deployment is a separate repository integration.')
b=node(65,10,300,80,'Workbench agents','Code + operational tools','primary')
b+=node(65,160,300,100,'Google Cloud SDK','gcloud · gsutil · bq|Logs, state and test deployments')
b+=node(65,335,300,100,'Cloudflare MCP','Scoped account / zone access|Analytics, DNS and configuration')
b+=wire('M215 90 V160')+wire('M65 50 H25 V385 H65')
cloud_m=svg('cloud-tools-mobile',430,465,b,'Cloud tools, mobile view','Google Cloud SDK and Cloudflare MCP are separate connections from the workbench.')
cloud_detail='<section id="cloud-tools"><div class="detail-intro"><span class="kicker">Workbench connections</span><h3>Agents can inspect the systems they work on</h3><p>Production logs and traffic analytics give an agent evidence for a diagnosis. Test deployments let it exercise a change outside its local checkout.</p></div><figure class="map"><div class="wide">'+cloud+'</div><div class="mobile">'+cloud_m+'</div></figure>'+'''<div class="mcp-tools cloud-notes"><div><h4>Google Cloud</h4><p><code>gcloud</code>, <code>gsutil</code> and <code>bq</code> support logs, resource inspection and authorised test builds. The workflow establishes the account and pins the project on each command.</p></div><div><h4>Cloudflare</h4><p>MCP supplies analytics and account or zone inspection. Test previews use the repository’s deployment integration; on this blog, CI finds the preview for the exact commit and captures browser evidence.</p></div><div><h4>Check the deployed result</h4><p>Browser tools inspect the test build. The agent reads the page, checks the behaviour and reviews screenshots. A successful deployment command alone is insufficient.</p></div></div><details class="deep"><summary>How cloud access stays scoped</summary><p>The Cloudflare inspection token does not grant Pages or Workers deployment writes. Production reads and authorised test deployments are distinct from production changes. The GCP command hook rejects covered destructive command patterns; project selection, IAM permissions and explicit review handle the wider boundary.</p></details></section>'''
quality_detail='''<section class="section repo-quality" id="repository-checks"><div class="section-head"><div><span class="kicker">Inside each repository</span><h2>Make the checks executable</h2></div><p>I use the Makefile as the command map for people, agents and CI. The repository’s instructions explain the conventions; executable checks give the agent specific failures to fix.</p></div><div class="command-map"><div><code>make format</code><p>Apply the formatter’s rules.</p></div><div><code>make check</code><p>Run the canonical validation gate.</p></div></div><div class="gate-grid"><article><h3>Formatting + lint</h3><p>Check consistent formatting and reject lint warnings. Style decisions become repeatable commands.</p></article><article><h3>Strict types</h3><p>Catch incompatible values, missing cases and unsafe assumptions before execution.</p></article><article><h3>Structural rules</h3><p>Check file size, function size, complexity and forbidden suppressions. A failed check must be fixed without weakening the rule.</p></article><article><h3>Tests + build</h3><p>Check behaviour, build the result, and exercise relevant interfaces. For this blog, the gate includes image checks and browser tests.</p></article></div><p class="detail-note">In this blog, Biome formats and lints, TypeScript checks types, Vitest runs unit tests, and Playwright checks browser behaviour. CI runs the same <code>make check</code> target. <code>make format</code> rewrites files; the gate’s format check rejects drift.</p><div class="test-example"><div><span class="kicker">Given · When · Then</span><h3>Tests should read like the behaviour they protect</h3><p>I require this structure: Given describes the starting state, When names the action, Then states the expected result. Each comment is a sentence a reviewer can read.</p><p>This example is from the blog’s reading-time tests. At 200 words per minute, 201 words must round up to two minutes.</p></div><pre>it("rounds 201 words up to two minutes", () =&gt; {
  // Given a Markdown body with 201 words.
  const body = Array(201).fill("word").join(" ");

  // When its reading time is estimated.
  const minutes = readingMinutes(body);

  // Then the estimate is two minutes.
  expect(minutes).toBe(2);
});</pre></div><p class="detail-note">A readable test must also be able to fail. Regression tests reproduce the defect; new tests must catch removal of the behaviour they protect. The final checks run against the integrated version being reviewed.</p></section>'''

def extra_detail(name):
    return {'team':role_detail,'mechanism':hook_detail+handoff_detail,'lab':mcp_detail,'deployment':cloud_detail}.get(name,'')

maps={'overview':(overview,overview_m),'deployment':(deployment,deployment_m),'team':(team,team_m),'flow':(flow,flow_m),'team-context':(team_context,team_context_m),'mechanism':(mechanism,mechanism_m),'lab':(lab,lab_m)}
def figure(name,caption=''):
    a,b=maps[name]
    content=f'<figure class="map"><div class="wide">{a}</div><div class="mobile">{b}</div>{f"<figcaption>{caption}</figcaption>" if caption else ""}</figure>'
    return '<div class="zoom-content">'+content+extra_detail(name)+'</div>'
css='''
:root{color-scheme:light dark;--bg:light-dark(#f5f5f5,#121212);--surface:light-dark(#fff,#1c1c1c);--text:light-dark(#161616,#ececec);--muted:light-dark(#4d4d4d,#a8a8a8);--line:light-dark(#cfcfcf,#3d4644);--accent:light-dark(#1a7359,#93b8a9);--wash:light-dark(#ecf1e6,#23382e);--ink:light-dark(#285a4b,#a8d7c3)}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:16px/1.6 system-ui,sans-serif}a{color:var(--accent);text-underline-offset:4px}a:focus-visible{outline:2px solid var(--accent);outline-offset:4px}header{max-width:1240px;margin:auto;display:flex;justify-content:space-between;align-items:center;gap:20px;padding:22px 28px;border-bottom:1px solid var(--line);font-size:13px}header a{text-decoration:none}.brand{color:var(--text);font-weight:600}.mock-label{font:11px/1.5 system-ui,sans-serif;letter-spacing:.09em;text-transform:uppercase;color:var(--muted)}main{max-width:1240px;margin:auto;padding:48px 28px 64px}h1,h2,h3,p{margin:0}h1,h2,h3{font-family:Georgia,serif;font-weight:400;line-height:1.15;text-wrap:balance}h1{font-size:clamp(2.5rem,5vw,4.7rem);letter-spacing:-.04em;max-width:20ch;margin:12px 0 20px}h2{font-size:clamp(1.7rem,3vw,2.6rem);letter-spacing:-.025em}h3{font-size:1.45rem}.lede{max-width:64ch;font-size:1.08rem;line-height:1.7;color:var(--muted)}.kicker{font:11px/1.4 system-ui,sans-serif;text-transform:uppercase;letter-spacing:.14em;color:var(--accent)}.jump{display:flex;flex-wrap:wrap;gap:12px 28px;margin:26px 0 36px;font-size:13px}.section{margin-top:56px}.section-head{display:grid;grid-template-columns:1fr 1fr;gap:40px;align-items:end;margin-bottom:24px}.section-head p{max-width:54ch;color:var(--muted);font-size:15px}.section-head .kicker{display:block;margin-bottom:10px}.map{margin:0;border:1px solid var(--line);background:var(--surface);border-radius:12px;overflow:hidden}.diagram{display:block;width:100%;height:auto;font-family:system-ui,sans-serif}.diagram .node{fill:var(--surface);stroke:var(--line);stroke-width:1.5}.diagram .primary{fill:var(--wash);stroke:var(--accent);stroke-width:1.5}.diagram .boundary{fill:var(--bg);stroke:var(--line);stroke-width:1.6;stroke-dasharray:7 5}.diagram .heading{fill:var(--text);font-size:20px;font-weight:600}.diagram .muted{fill:var(--muted);font-size:15px}.diagram .boundary-title{fill:var(--text);font-size:17px;font-weight:600}.diagram .wire{fill:none;stroke:var(--accent);stroke-width:2}.diagram .secondary{stroke-dasharray:6 4}.diagram .arrowhead{fill:var(--accent)}.diagram .label{fill:var(--accent);font-size:14px;paint-order:stroke;stroke:var(--surface);stroke-width:5px;stroke-linejoin:round}figcaption{font-size:12px;line-height:1.6;color:var(--muted);padding:14px 20px;border-top:1px solid var(--line)}.mobile{display:none}.decisions{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:22px}.decisions p{font-size:14px;line-height:1.7;color:var(--muted)}.decisions b{display:block;color:var(--text);font-size:14px;font-weight:550;margin-bottom:6px}.capture{margin:22px 0 0;display:grid;grid-template-columns:1.45fr 1fr;border:1px solid var(--line);border-radius:12px;overflow:hidden;background:var(--surface)}.capture img{width:100%;height:auto;display:block}.capture figcaption{padding:28px;border:0;align-self:center;font-size:14px}.capture h3{margin-bottom:16px;color:var(--text)}.capture p{margin-bottom:14px}.footnotes{display:grid;grid-template-columns:1fr 1fr;gap:48px;border-top:1px solid var(--line);margin-top:50px;padding-top:28px;font-size:14px;color:var(--muted)}.footnotes b{display:block;color:var(--text);margin-bottom:8px}.footnotes p+p{margin-top:14px}footer{max-width:1240px;padding:20px 28px;margin:auto;border-top:1px solid var(--line);font-size:12px;color:var(--muted)}.blueprint{color-scheme:dark;--bg:#111a20;--surface:#17232a;--text:#e7eeee;--muted:#a5b8bb;--line:#3d535c;--accent:#88cbbb;--wash:#203b3b;--ink:#a8d7c3}.blueprint h1,.blueprint h2,.blueprint h3{font-family:system-ui,sans-serif;font-weight:500;letter-spacing:-.045em}.blueprint main{max-width:1440px;padding-top:34px}.blueprint header,.blueprint footer{max-width:1440px}.blueprint h1{font-size:clamp(2.3rem,4vw,3.5rem);max-width:none}.blueprint .map{border-radius:0}.blueprint .hero-line{display:flex;gap:40px;justify-content:space-between;align-items:end;margin-bottom:26px}.blueprint .hero-line .lede{max-width:45ch;font-size:15px}.sheet-pair{display:grid;grid-template-columns:1fr 1fr;gap:28px;margin-top:34px}.sheet-pair h2{font-size:1.55rem;margin-bottom:10px}.sheet-pair p{font-size:14px;color:var(--muted);margin-bottom:18px}.sheet-pair .diagram .heading{font-size:22px}.blueprint .section-head{margin-top:38px}.tour main{max-width:1240px}.tour .hero{display:grid;grid-template-columns:1fr 1.15fr;gap:44px;align-items:center}.tour .hero img{display:block;width:100%;border-radius:12px;border:1px solid var(--line)}.tour h1{font-size:clamp(2.4rem,4.4vw,4rem)}.tour .scene{display:grid;grid-template-columns:280px 1fr;gap:42px;border-top:1px solid var(--line);padding-top:34px;margin-top:46px}.tour .scene h2{font-size:2rem;margin:12px 0 18px}.tour .scene p{font-size:14px;color:var(--muted)}.tour .scene .diagram .heading{font-size:21px}.options{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin:35px 0}.option{border:1px solid var(--line);padding:24px;background:var(--surface);border-radius:10px}.option h2{font-size:1.7rem;margin:20px 0 14px}.option p{font-size:14px;color:var(--muted);margin:16px 0}.option .thumb{height:195px;background:var(--bg);padding:17px;border:1px solid var(--line);overflow:hidden}.thumb .diagram{height:100%;width:100%}.thumb.dark{background:#17232a;--surface:#17232a;--bg:#111a20;--text:#e7eeee;--line:#3d535c;--muted:#a5b8bb;--accent:#88cbbb;--wash:#203b3b}.thumb img{width:100%;height:100%;object-fit:cover;object-position:top}.option a{font-weight:550;font-size:14px}.intro-label{display:block;margin-bottom:12px}.legend{font-size:12px;color:var(--muted);display:flex;gap:20px;margin-top:10px}.legend span{display:flex;align-items:center;gap:7px}.legend i{width:24px;border-top:2px solid var(--accent)}.legend .dashed{border-top-style:dashed}
@media(max-width:700px){header{padding:16px 20px;gap:10px;flex-wrap:wrap}main{padding:30px 20px 45px}.wide{display:none}.mobile{display:block}.section-head,.decisions,.capture,.footnotes,.sheet-pair,.tour .hero,.tour .scene,.options{grid-template-columns:1fr;gap:20px}.section-head{margin-bottom:20px}.section-head p{font-size:14px}.section{margin-top:40px}.decisions{gap:16px}.capture figcaption{padding:22px}.diagram .heading{font-size:20px}.diagram .label{font-size:14px}.diagram .muted{font-size:15px}.blueprint .hero-line{display:block}.blueprint .hero-line .lede{margin-top:18px}.tour .hero{gap:28px}.tour .scene{margin-top:30px;padding-top:24px}.tour .scene h2{margin:8px 0 12px}.footnotes{gap:26px}.option .thumb .wide{display:block}.option .thumb .mobile{display:none}.jump{gap:10px 20px;margin-bottom:25px}.legend{flex-wrap:wrap}.blueprint .sheet-pair .diagram .heading{font-size:20px}.tour .scene .diagram .heading{font-size:20px}}
'''
(p/'visual.css').write_text(css)

def page(title,body,cls=''):
    return f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>{title}</title><link rel="stylesheet" href="visual.css"></head><body class="{cls}"><header><a class="brand" href="index.html">Andrew McDonald</a><span class="mock-label">Visual proposal · round 2</span><a href="index.html">Compare directions</a></header>{body}<footer>Designed architecture · <a href="https://mattbalshaw.com/agentic-engineering">Inspired by Matt Balshaw’s workflow page</a> · <a href="sources.html">Research notes</a></footer></body></html>'

def head(level,title,copy):
    return f'<div class="section-head"><div><span class="kicker">{level}</span><h2>{title}</h2></div><p>{copy}</p></div>'

proof='''<figure class="capture"><a href="team-workflow.jpg"><img src="team-workflow.jpg" alt="A real run showing 29 tasks across nine steps, converging on a final check that was sent back twice." loading="lazy"></a><figcaption><span class="kicker intro-label">The design in use</span><h3>A real team run</h3><p>29 tasks, nine steps. The final check was sent back after the code changed. Its earlier result could not stand in for checks on the new version.</p><a href="team-dashboard.jpg">Open the dashboard screenshot →</a></figcaption></figure>'''
foot='''<div class="footnotes"><div><b>What I engineered</b><p><code>agent-toolkit</code>: shared instructions, team contracts, the task ledger, hooks and observer.</p><p><code>workbench-infra</code>: the workbench integration and a gateway that manages disposable machines and storage.</p></div><div><b>What the trials changed</b><p>I compared teams with single agents on three tasks. Extra review caught defects on harder work, but teams took longer. Small changes stay with one agent; I use teams when review is worth the cost.</p></div></div>'''

intro='Agents handle judgement; code handles repeatable checks. Each task gets only the context it needs, keeping the main thread focused on decisions. A private workbench and disposable lab support the workflow.'
levels=[
 ('environment-v0','Environment · V0','The whole setup','My browser reaches the workbench through Tailscale. The workbench connects to hosted models, a disposable test lab and cloud services for logs, analytics and test builds.','overview'),
 ('environment-v1','Environment · V1','Open up the workbench and lab','Proxmox hosts the machines; TrueNAS supplies temporary files. T3 launches the coding clients. The lab-control MCP gateway gives agents bounded tools for Proxmox and TrueNAS.','deployment'),
 ('environment-v2','Environment · V2','Follow a test environment','Request a lease, check limits, create the guest, run the test, then verify ownership before cleanup.','lab'),
 ('team-v0','Lead-team · V0','From a goal to a reviewed result','I set the outcome and constraints. The team returns work and evidence for my decision. Small changes can stay with one agent.','team-context'),
 ('team-v1','Lead-team · V1','A graph of bounded tasks','The main thread keeps the goal and decisions. Each node gets a scoped brief, relevant context and a model suited to its work. Evidence returns to the lead.','team'),
 ('team-v2','Lead-team · V2','An enforced contract at every handoff','Agents can forget instructions, omit evidence or report success incorrectly. Typed contracts and hooks check what passes between them. The lead still judges whether the evidence proves the work.','mechanism')]
core='<div class="principle"><span class="kicker">The design principle</span><p>Agents judge. Code checks.<br>Context follows responsibility.</p><span>Prose alone is unreliable. Typed contracts and hooks check the handoffs; the lead judges the evidence.</span></div>'
body='<main><span class="kicker">A · Two systems, three scales each</span><h1>My agentic engineering setup</h1><p class="lede">'+intro+'</p><nav class="jump" aria-label="Explore the architecture"><a href="#environment-v0">Explore the environment ↓</a><a href="#team-v0">Explore lead-team ↓</a><a href="#repository-checks">Repository checks ↓</a></nav>'+core
for sid,level,title,copy,name in levels:
 body+=f'<section class="section" id="{sid}">'+head(level,title,copy)+figure(name, 'Green boxes require agent judgement; other boxes are code or records. Failed report checks trigger correction or retain explicit problems for the lead. Passing format checks is not acceptance.' if name=='mechanism' else '')+'</section>'
body+=proof+quality_detail+foot+'</main>'
(p/'a-case-study.html').write_text(page('A · Environment and lead-team at three scales',body))

body='<main><div class="hero-line"><div><span class="kicker">B · System blueprint</span><h1>The agentic workbench</h1></div><p class="lede">'+intro+'</p></div>'
body+='<div class="sheet-context">'+head('Environment · V0','Context','Private access, a persistent workspace and a disposable test lab.')+figure('overview')+'</div>'
body+=head('Environment · V1','Deployment','Machine boundaries and the connections between them.')+figure('deployment')
body+='<details class="deep"><summary>Environment V2 · Follow a lab request</summary>'+figure('lab')+'</details>'
body+='<section class="section">'+head('Lead-team · V0','The contract with me','An outcome goes in. A reviewed result and its evidence come back.')+figure('team-context')+'</section>'
body+='<section class="section">'+head('Lead-team · V1','Responsibility','A task graph with scoped context, models matched to the work, and evidence returned to the lead.')+figure('team')+'</section>'
body+='<section class="section">'+head('Lead-team · V2','Enforced handoffs','Agents can forget or misreport. Typed contracts and hooks check records; the lead judges the evidence.')+figure('mechanism','Failed report checks trigger correction or retain explicit problems for the lead. A reported result still needs acceptance.')+'</section>'+proof+quality_detail+foot+'</main>'
(p/'b-workflow-page.html').write_text(page('B · The system blueprint',body,'blueprint'))

body='<main><div class="hero"><div><span class="kicker">C · Decisions and mechanisms</span><h1>Where judgement ends and code takes over</h1><p class="lede">Prose alone is unreliable. Agents make contextual decisions; code checks repeatable rules. Each task holds only the work and context it needs.</p></div><a href="team-workflow.jpg"><img src="team-workflow.jpg" alt="The real dashboard: parallel tasks converge on a final check with two recorded send-backs."></a></div>'
body+='<div class="decision-pair"><div><span class="kicker">Agents judge</span><h3>What should happen?</h3><p>Scope the task. Choose an approach. Interpret failures. Review the result.</p></div><div><span class="kicker">Code checks</span><h3>Do the rules hold?</h3><p>Validate the contract. Check dependencies. Run tests. Record state changes.</p></div></div>'
for sid,level,title,copy,name in levels[3:]+levels[:3]:
 body+=f'<section class="scene" id="{sid}"><div><span class="kicker">{level}</span><h2>{title}</h2><p>{copy}</p></div>'+figure(name, 'Green boxes require agent judgement; other boxes are code or records. Failed report checks trigger correction or retain explicit problems for the lead. Passing format checks is not acceptance.' if name=='mechanism' else '')+'</section>'
body+=quality_detail+foot+'</main>'
(p/'c-essay.html').write_text(page('C · Decisions and mechanisms',body,'tour'))

body='<main><span class="kicker">Round 2 · Diagrams first</span><h1>Understand the system at a glance</h1><p class="lede">Each direction has two zoom sequences: environment V0–V2 and lead-team V0–V2. The central distinction is judgement by agents, mechanical checks in code.</p><div class="options">'
for label,title,desc,link,thumb in [('A · Recommended','An architecture atlas','Start wide, then zoom in. Two clear sequences of large diagrams, with short captions at each level.','a-case-study.html',f'<div class="thumb">{deployment.replace("deployment", "thumb-a")}</div>'),('B · Blueprint','A technical system sheet','A dark blueprint with deployment boundaries, team structure and the decision/check cycle. Lab internals expand on demand.','b-workflow-page.html',f'<div class="thumb dark">{deployment.replace("deployment", "thumb-b")}</div>'),('C · Principle first','Judgement and mechanics','Lead with the design principle and real dashboard. Explore the team first, then the environment that supports it.','c-essay.html','<div class="thumb"><img src="team-workflow.jpg" alt="Real workflow graph"></div>')]:
 body+=f'<section class="option"><span class="kicker">{label}</span><h2>{title}</h2>{thumb}<p>{desc}</p><a href="{link}">Open this direction →</a></section>'
body+='</div><p class="lede">The diagrams describe the designed architecture, including the disposable lab. Current hardware limits are left out of the portfolio page.</p></main>'
(p/'index.html').write_text(page('Agentic workflow — visual directions',body))
with (p/'visual.css').open('a') as style:
 style.write('.principle{border-left:3px solid var(--accent);padding:5px 0 5px 24px;margin:30px 0 55px}.principle p{font:clamp(1.4rem,2.5vw,2rem)/1.4 Georgia,serif;margin:10px 0}.principle>span:last-child{font-size:13px;color:var(--muted)}.decision-pair{display:grid;grid-template-columns:1fr 1fr;gap:30px;margin:38px 0}.decision-pair>div{border-top:2px solid var(--accent);padding-top:20px}.decision-pair h3{margin:12px 0}.decision-pair p{color:var(--muted);font-size:14px}.deep{margin-top:20px;border:1px solid var(--line);padding:16px}.deep summary{cursor:pointer}.deep[open] summary{margin-bottom:20px}.sheet-context{max-width:900px;margin:30px auto 40px}.sheet-context .section-head{margin-top:0}@media(max-width:700px){.decision-pair{grid-template-columns:1fr}.principle{padding-left:18px}.deep{padding:10px}}')
print('Built separate environment and lead-team V0–V2 sequences, organised around judgement and code.')

with (p/'visual.css').open('a') as style:
 style.write(".zoom-content{min-width:0}.detail-intro{margin:28px 0 20px}.detail-intro h3{margin:8px 0 12px}.detail-intro p,.handoff-detail p,.deep p{font-size:14px;color:var(--muted);max-width:80ch}.handoff-pair{display:grid;grid-template-columns:1fr 1fr;gap:22px}.handoff-pair article{padding:22px;border:1px solid var(--line);background:var(--surface);min-width:0;border-radius:10px}.handoff-pair dl{margin:20px 0}.handoff-pair dt,.rules-list dt{font-size:13px;font-weight:650;margin-top:14px}.handoff-pair dd,.rules-list dd{margin:3px 0 0;font-size:14px;color:var(--muted)}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.8 ui-monospace,monospace;background:var(--bg);padding:16px;border-radius:6px}code{font-size:.88em;overflow-wrap:anywhere}summary{cursor:pointer;font-size:14px;font-weight:550}summary:focus-visible{outline:2px solid var(--accent);outline-offset:4px}.rejection{border-left:3px solid var(--accent);padding:10px 20px;margin:24px 0}.rejection blockquote{margin:14px 0;font:13px/1.7 ui-monospace,monospace;overflow-wrap:anywhere}.acceptance{padding:20px;border:1px solid var(--line);border-radius:10px}.acceptance p{margin-top:12px}.state-track{display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin:20px 0;font:13px/1.6 ui-monospace,monospace}.state-track span{padding:8px 12px;background:var(--wash);border:1px solid var(--accent);border-radius:6px}.state-track i{font-style:normal}.state-track small{display:block}.role-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:24px;margin:24px 0}.role-grid h3{font:600 14px/1.5 system-ui,sans-serif;margin-bottom:6px}.detail-note{margin:20px 0 0}.mcp-tools{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}.mcp-tools p{font-size:14px;color:var(--muted);margin-top:8px}.deep p+p{margin-top:16px}.rules-list{margin:20px 0}.tour .handoff-pair{grid-template-columns:1fr}.tour .mcp-tools{grid-template-columns:1fr}@media(max-width:700px){.handoff-pair,.role-grid,.mcp-tools{grid-template-columns:1fr}.handoff-pair article{padding:16px}.state-track{gap:7px}.state-track span{padding:6px 8px;font-size:11px}}")

with (p/'visual.css').open('a') as style:
 style.write(".hook-catalog{margin-top:30px}.hook-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:22px}.hook-grid article{border-top:2px solid var(--accent);padding:16px 0}.hook-grid code{font-size:15px;color:var(--accent)}h4{font-size:14px;margin:10px 0}.hook-grid p,.hook-grid span{font-size:13px;line-height:1.7}.hook-grid span{display:block;color:var(--muted);margin-top:12px}.cloud-notes{margin:22px 0}.command-map{display:grid;grid-template-columns:1fr 1fr;gap:24px;border:1px solid var(--line);padding:24px;background:var(--surface)}.command-map code{font-size:20px;color:var(--accent)}.command-map p,.gate-grid p,.test-example p{font-size:14px;color:var(--muted);margin-top:12px}.gate-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:24px;margin:26px 0}.gate-grid h3{font:600 15px/1.5 system-ui,sans-serif}.test-example{display:grid;grid-template-columns:1fr 1.2fr;gap:32px;align-items:center;margin-top:40px}.test-example h3{margin-top:12px}.test-example pre{border:1px solid var(--line);background:var(--surface);min-width:0}.tour .hook-grid{grid-template-columns:repeat(2,1fr)}@media(max-width:700px){.hook-grid,.tour .hook-grid,.command-map,.test-example{grid-template-columns:1fr}.gate-grid{grid-template-columns:1fr 1fr}.hook-grid{gap:8px}.test-example{gap:12px}}")

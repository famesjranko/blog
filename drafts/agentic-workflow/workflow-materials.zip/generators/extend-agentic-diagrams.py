from pathlib import Path
f=Path('/tmp/build-agentic-visual-mocks.py')
s=f.read_text()
insert='''
# The team has its own context view, separate from the infrastructure scale.
b=node(20,105,230,95,'My goal','Outcome + constraints')+node(360,80,285,145,'lead-team','Agents coordinate the work|Code checks the process','primary')+node(755,105,255,95,'Reviewed result','Evidence for my decision')
b+=wire('M250 152 H360')+wire('M645 152 H755')
team_context=svg('team-context',1040,270,b,'Team V0: goal to reviewed result','I give a goal and constraints to the team workflow. It returns an integrated result and evidence for my review. Agents judge the work while code checks mechanical rules.')
b=node(65,10,300,90,'My goal','Outcome + constraints')+node(65,165,300,120,'lead-team','Agents coordinate the work|Code checks the process','primary')+node(65,350,300,90,'Reviewed result','Evidence for my decision')
b+=wire('M215 100 V165')+wire('M215 285 V350')
team_context_m=svg('team-context-mobile',430,470,b,'Team V0: goal to reviewed result','A goal enters the team workflow. A reviewed result and its evidence return to me.')

# V1 team hierarchy: no serial arrows implying that workers manage reviewers.
b=node(405,10,260,72,'Me','Scope + merge decision')+node(405,130,260,85,'Lead agent','Delegates and judges','primary')
for x,title,sub in [(20,'Planner','Divides the goal'),(285,'Workers','Separate worktrees'),(550,'Reviewer','Independent judgement'),(815,'Check runner','Runs named commands')]:
 b+=node(x,330,235,86,title,sub,'primary' if title=='Workers' else 'node')
 b+=wire(f'M535 215 V275 H{x+117.5} V330')
b+=wire('M535 82 V130')
b+='<text class="label" x="535" y="478" text-anchor="middle">Scoped briefs go down. Results and evidence come back.</text>'
team=svg('team',1080,510,b,'Team V1: roles and responsibility','The lead delegates to a planner, workers, reviewer and check runner. They report to the lead. The lead judges intermediate results; I retain scope and merge decisions.')
b=node(65,10,300,70,'Me','Scope + merge decision')+node(65,135,300,85,'Lead agent','Delegates and judges','primary')
b+=wire('M215 80 V135')
for y,title,sub in [(285,'Planner','Divides the goal'),(415,'Workers','Separate worktrees'),(545,'Reviewer','Independent judgement'),(675,'Check runner','Runs named commands')]:
 b+=node(90,y,300,85,title,sub,'primary' if title=='Workers' else 'node')
 b+=wire(f'M65 178 H30 V{y+42} H90')
b+='<text class="label" x="215" y="818" text-anchor="middle">Briefs go down. Evidence comes back.</text>'
team_m=svg('team-mobile',430,850,b,'Team V1: roles and responsibility','Every specialist reports to the lead. The branches show responsibility, not task order.')

# V2: the central design separation, paired at each handoff.
judgements=[('Define the task','Goal, scope and evidence'),('Assign the work','Choose a role and model'),('Build and review','Interpret results; find defects'),('Accept or send back','Judge whether the goal is met')]
mechanisms=[('Validate the contract','Required fields and dependencies'),('Check the handoff','Spawn hook matches the contract'),('Run checks','Tests, report shape, file ownership'),('Record the decision','Ledger state gates dependent work')]
b=box(20,20,480,650,'JUDGEMENT · AGENTS','Decisions that depend on context')+box(620,20,480,650,'MECHANICAL · CODE','Repeatable checks and state changes')
for i,((title,sub),(code,csub)) in enumerate(zip(judgements,mechanisms)):
 y=125+i*135
 b+=node(65,y,390,85,title,sub,'primary')+node(665,y,390,85,code,csub)+wire(f'M455 {y+42} H665')
 if i<3:b+=wire(f'M665 {y+72} H570 V{y+117} H260 V{y+135}',dash=True)
b+=node(355,735,410,86,'Observer dashboard','Reads the ledger and activity logs')+wire('M860 615 V702 H560 V735')
mechanism=svg('mechanism',1120,850,b,'Team V2: judgement and mechanical enforcement','Agents define tasks, assign work, interpret evidence and decide acceptance. Code validates contracts, gates spawns, runs tests, checks reports and records decisions. The ledger gates dependent work. The dashboard reads the ledger and activity logs; it does not decide whether the work is correct.')
b=''
for i,((title,sub),(code,csub)) in enumerate(zip(judgements,mechanisms)):
 y=15+i*285
 b+=node(35,y,360,95,title,'Agent judgement · '+sub,'primary')
 b+=node(35,y+140,360,95,code,'Code · '+csub)
 b+=wire(f'M215 {y+95} V{y+140}')
 if i<3:b+=wire(f'M215 {y+235} V{y+285}',dash=True)
b+=node(35,1180,360,86,'Observer dashboard','Reads task state and activity')+wire('M215 1105 V1180')
mechanism_m=svg('mechanism-mobile',430,1300,b,'Team V2: judgement and code','Each agent decision is followed by a mechanical check or recorded state change. Code checks the process; agents judge the meaning of the evidence.')

# Environment V2: expand the lab into a bounded lifecycle.
b=node(20,70,220,95,'Agent request','CPU, memory, storage|Time limit')+node(330,70,330,95,'lab-control','Check capacity and policy|Record a lease','primary')
b+=node(760,15,310,85,'Proxmox','Create a Debian guest')+node(760,205,310,85,'TrueNAS','Create temporary storage')
b+=wire('M240 117 H330','MCP',285,98)+wire('M660 95 H710 V57 H760')+wire('M660 140 H710 V247 H760')
b+=node(760,390,310,95,'Run the test','Agent → guest over SSH|Guest → files over NFS','primary')
b+=wire('M1070 57 H1100 V437 H1070')+wire('M915 290 V390')
b+=node(330,390,330,95,'Release the lease','Verify ownership|Remove guest and storage')+wire('M760 437 H660')
b+='<text class="label" x="485" y="550" text-anchor="middle">A partial failure is recorded for investigation.</text>'
lab=svg('lab',1130,585,b,'Environment V2: disposable lab lifecycle','An agent requests a bounded lease. lab-control checks policy and capacity, records ownership, creates a Proxmox guest and optional TrueNAS storage. The agent tests over SSH and uses NFS files. Release verifies ownership before cleanup. Partial failures are recorded.')
b=''
items=[('Agent request','Machine size + expiry'),('lab-control','Check policy; record the lease'),('Proxmox + TrueNAS','Create guest + optional storage'),('Run the test','SSH into guest; mount NFS files'),('Release','Check ownership; clean up')]
for i,(title,sub) in enumerate(items):
 y=15+i*145;b+=node(35,y,360,95,title,sub,'primary' if i in [1,3] else 'node')
 if i<4:b+=wire(f'M215 {y+95} V{y+145}')
lab_m=svg('lab-mobile',430,725,b,'Environment V2: lab lifecycle','Request, validate, provision, test and release. Partial failures stay on record for investigation.')
'''
s=s.replace("maps={'overview':",insert+"\nmaps={'overview':")
s=s.replace("'flow':(flow,flow_m)}","'flow':(flow,flow_m),'team-context':(team_context,team_context_m),'mechanism':(mechanism,mechanism_m),'lab':(lab,lab_m)}")
# Make room for the plain-language judgement label on mobile.
s=s.replace("b+=node(35,y,360,95,title,'Agent judgement · '+sub,'primary')","b+=node(35,y,360,95,title,'Agent judgement|'+sub,'primary')")
s=s.replace("b+=node(35,y+140,360,95,code,'Code · '+csub)","b+=node(35,y+140,360,95,code,'Code|'+csub)")
start=s.index("body='<main><span class=\"kicker\">A ·")
s=s[:start]+'''
intro='I separate judgement from mechanics: agents plan and review; code checks contracts, runs tests and records decisions. A private workbench and disposable test lab support the workflow.'
levels=[
 ('environment-v0','Environment · V0','The whole setup','My browser reaches the workbench through Tailscale. The workbench connects to hosted models and an on-demand test lab.','overview'),
 ('environment-v1','Environment · V1','Open up the workbench and lab','Proxmox hosts the machines; TrueNAS supplies temporary files. T3 launches the coding clients. A gateway controls infrastructure operations.','deployment'),
 ('environment-v2','Environment · V2','Follow a test environment','Request a lease, check limits, create the guest, run the test, then verify ownership before cleanup.','lab'),
 ('team-v0','Lead-team · V0','From a goal to a reviewed result','I set the outcome and constraints. The team returns work and evidence for my decision. Small changes can stay with one agent.','team-context'),
 ('team-v1','Lead-team · V1','Open up the team','The lead delegates and judges. Specialists plan, build, review and run checks. Each worker has its own working copy.','team'),
 ('team-v2','Lead-team · V2','Judgement stays with agents. Mechanics live in code.','Prose alone is unreliable. Contracts, hooks and the ledger make specific rules checkable; agents decide whether the evidence is convincing.','mechanism')]
core='<div class="principle"><span class="kicker">The design principle</span><p>Agents exercise judgement.<br>Code handles the mechanical parts.</p><span>Instructions explain the intent. Executable checks make specific rules hold.</span></div>'
body='<main><span class="kicker">A · Two systems, three scales each</span><h1>My agentic engineering setup</h1><p class="lede">'+intro+'</p><nav class="jump" aria-label="Explore the architecture"><a href="#environment-v0">Explore the environment ↓</a><a href="#team-v0">Explore lead-team ↓</a></nav>'+core
for sid,level,title,copy,name in levels:
 body+=f'<section class="section" id="{sid}">'+head(level,title,copy)+figure(name)+'</section>'
body+=proof+foot+'</main>'
(p/'a-case-study.html').write_text(page('A · Environment and lead-team at three scales',body))

body='<main><div class="hero-line"><div><span class="kicker">B · System blueprint</span><h1>The agentic workbench</h1></div><p class="lede">'+intro+'</p></div>'
body+='<div class="sheet-context">'+head('Environment · V0','Context','Private access, a persistent workspace and a disposable test lab.')+figure('overview')+'</div>'
body+=head('Environment · V1','Deployment','Machine boundaries and the connections between them.')+figure('deployment')
body+='<details class="deep"><summary>Environment V2 · Follow a lab request</summary>'+figure('lab')+'</details>'
body+='<section class="section">'+head('Lead-team · V0','The contract with me','An outcome goes in. A reviewed result and its evidence come back.')+figure('team-context')+'</section>'
body+='<section class="section">'+head('Lead-team · V1','Responsibility','The lead coordinates specialists; each reports its evidence.')+figure('team')+'</section>'
body+='<section class="section">'+head('Lead-team · V2','Judgement / mechanics','Agents make decisions. Code checks the handoffs and records state.')+figure('mechanism')+'</section>'+proof+foot+'</main>'
(p/'b-workflow-page.html').write_text(page('B · The system blueprint',body,'blueprint'))

body='<main><div class="hero"><div><span class="kicker">C · Decisions and mechanisms</span><h1>Where judgement ends and code takes over</h1><p class="lede">Prose alone is unreliable. I give agents the decisions that need context, and put repeatable checks into code.</p></div><a href="team-workflow.jpg"><img src="team-workflow.jpg" alt="The real dashboard: parallel tasks converge on a final check with two recorded send-backs."></a></div>'
body+='<div class="decision-pair"><div><span class="kicker">Agents judge</span><h3>What should happen?</h3><p>Scope the task. Choose an approach. Interpret failures. Review the result.</p></div><div><span class="kicker">Code checks</span><h3>Do the rules hold?</h3><p>Validate the contract. Check dependencies. Run tests. Record state changes.</p></div></div>'
for sid,level,title,copy,name in levels[3:]+levels[:3]:
 body+=f'<section class="scene" id="{sid}"><div><span class="kicker">{level}</span><h2>{title}</h2><p>{copy}</p></div>'+figure(name)+'</section>'
body+=foot+'</main>'
(p/'c-essay.html').write_text(page('C · Decisions and mechanisms',body,'tour'))

body='<main><span class="kicker">Round 2 · Diagrams first</span><h1>Understand the system at a glance</h1><p class="lede">Each direction has two zoom sequences: environment V0–V2 and lead-team V0–V2. The central distinction is judgement by agents, mechanical checks in code.</p><div class="options">'
for label,title,desc,link,thumb in [('A · Recommended','An architecture atlas','Start wide, then zoom in. Two clear sequences of large diagrams, with short captions at each level.','a-case-study.html',f'<div class="thumb">{deployment}</div>'),('B · Blueprint','A technical system sheet','A dark blueprint with deployment boundaries, team structure and the decision/check cycle. Lab internals expand on demand.','b-workflow-page.html',f'<div class="thumb dark">{deployment}</div>'),('C · Principle first','Judgement and mechanics','Lead with the design principle and real dashboard. Explore the team first, then the environment that supports it.','c-essay.html','<div class="thumb"><img src="team-workflow.jpg" alt="Real workflow graph"></div>')]:
 body+=f'<section class="option"><span class="kicker">{label}</span><h2>{title}</h2>{thumb}<p>{desc}</p><a href="{link}">Open this direction →</a></section>'
body+='</div><p class="lede">The diagrams describe the designed architecture, including the disposable lab. Current hardware limits are left out of the portfolio page.</p></main>'
(p/'index.html').write_text(page('Agentic workflow — visual directions',body))
with (p/'visual.css').open('a') as style:
 style.write('.principle{border-left:3px solid var(--accent);padding:5px 0 5px 24px;margin:30px 0 55px}.principle p{font:clamp(1.4rem,2.5vw,2rem)/1.4 Georgia,serif;margin:10px 0}.principle>span:last-child{font-size:13px;color:var(--muted)}.decision-pair{display:grid;grid-template-columns:1fr 1fr;gap:30px;margin:38px 0}.decision-pair>div{border-top:2px solid var(--accent);padding-top:20px}.decision-pair h3{margin:12px 0}.decision-pair p{color:var(--muted);font-size:14px}.deep{margin-top:20px;border:1px solid var(--line);padding:16px}.deep summary{cursor:pointer}.deep[open] summary{margin-bottom:20px}.sheet-context{max-width:900px;margin:30px auto 40px}.sheet-context .section-head{margin-top:0}@media(max-width:700px){.decision-pair{grid-template-columns:1fr}.principle{padding-left:18px}.deep{padding:10px}}')
print('Built separate environment and lead-team V0–V2 sequences, organised around judgement and code.')
'''
f.write_text(s)

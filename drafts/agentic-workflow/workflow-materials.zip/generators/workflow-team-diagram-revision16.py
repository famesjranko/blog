# The role map describes authority, not a mandatory pipeline or fixed headcount.
roles = [
 ('Planner', 'Propose scoped|task contracts', 'Propose task contracts'),
 ('Explorer', 'Survey code or|probe a specific risk', 'Survey · focused probes'),
 ('Worker', 'Implement code,|tests and documents', 'Implement code and tests'),
 ('Reviewer', 'Judge the|integrated change', 'Judge the integrated result'),
 ('Chore', 'Run specified checks|and report output', 'Run checks · report output'),
]
b = node(20,220,245,105,'Lead','Assign · accept|Send back','primary')
# Assignment trunk is to the left of the roles; reports return around their right.
b += '<path class="wire" d="M265 255 H310 M310 55 V475"/>'
for i,(title,_,sub) in enumerate(roles):
 y = 20 + i*105
 b += node(355,y,315,70,title,sub)
 b += wire(f'M310 {y+35} H355')
 b += f'<path class="wire secondary" d="M670 {y+35} H695"/>'
b += wire('M695 55 V535 H142 V325',dash=True)
b += '<text class="label" x="355" y="575" text-anchor="middle">Solid: lead assigns or sends back.</text><text class="label" x="355" y="602" text-anchor="middle">Dashed: each role reports to the lead.</text>'
team = svg('story-team',715,625,b,'Five task roles report to the lead','Planner, Explorer, Worker, Reviewer and Chore are available task roles. The lead assigns each contract; every role reports back to the lead. The rows are not an execution sequence. Task dependencies are stored separately.')
b = node(45,10,340,85,'Lead','Assign · accept · send back','primary')
# Draw the shared trunks once, then one branch per role.
b += '<path class="wire" d="M45 53 H20 V565"/>'
b += wire('M410 565 V53 H385',dash=True)
for i,(title,_,sub) in enumerate(roles):
 y = 150 + i*95
 b += node(65,y,300,70,title,sub)
 b += wire(f'M20 {y+35} H65')
 b += f'<path class="wire secondary" d="M365 {y+35} H410"/>'
b += '<text class="label" x="215" y="643" text-anchor="middle">Solid: lead assigns or sends back.</text><text class="label" x="215" y="670" text-anchor="middle">Dashed: every agent reports to the lead.</text>'
team_m = svg('story-team-mobile',430,695,b,'Five task roles report to the lead','The lead assigns work to each selected role through the left solid path. Each role reports through the right dashed path. Planner, Explorer, Worker, Reviewer and Chore are separate roles, not sequential steps. Only the lead accepts work.')

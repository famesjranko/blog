from pathlib import Path
from shutil import copyfile
import re
root=Path('/home/andy/.t3/artifacts/agentic-workflow-20261009')
copyfile(root/'d-workflow.html',root/'d-revision20.html')
copyfile(root/'d-workflow.css',root/'d-revision20.css')
p=Path('/tmp/build-workflow-story.py')
s=p.read_text();Path('/tmp/build-workflow-story-revision20.py').write_text(s)
test=re.search(r'<div class="test">.*?</div>',s,re.S).group()
hooks=re.search(r'<details><summary>The six hooks and their limits</summary>.*?</details>',s,re.S).group()
models=re.search(r'<details><summary>Task context and model choice</summary>.*?</details>',s,re.S).group()
agentcard=re.search(r'<details><summary>Inspect an agent’s context and activity</summary>.*?</details>',s,re.S).group()
invocation=re.search(r'<details><summary>The two invocation settings</summary>.*?</details>',s,re.S).group()
body='''<header><a href="index.html">Andrew McDonald</a><span>Portfolio draft</span><a href="sources.html">Source notes</a></header>
<main><div class="hero"><span class="eyebrow">Solo development · Agentic engineering</span><h1>How I work as a solo developer</h1><p class="intro">I use Claude and Codex across my projects, often moving between different languages and frameworks. I give capable models a clear outcome and room to work out the implementation, with the repository providing the checks and constraints that fit the project.</p><p>A lot of the setup comes down to deciding what needs judgement and what can be checked in code. Here’s how that fits together, from a single coding session to a team working in parallel.</p></div>
<nav aria-label="On this page"><a href="#workflow">Workflow</a><a href="#projects">Project layers</a><a href="#team">Agent team</a><a href="#environment">Workbench</a><a href="#toolkit">Toolkit</a></nav>
<section id="workflow"><div class="section-heading"><span class="eyebrow">01 · The workflow</span><h2>From idea to merge</h2><p>The amount of planning depends on the change. A small fix can go straight to implementation.</p></div>
<ol class="flow-grid">
<li><span>01</span><div><h3>Brief</h3><p>Scope and acceptance criteria, usually in a GitHub issue.</p></div></li>
<li><span>02</span><div><h3>Plan</h3><p>Choose the approach and divide the work where useful.</p></div></li>
<li><span>03</span><div><h3>Build</h3><p>Implement in an isolated worktree, with tests for the behaviour.</p></div></li>
<li><span>04</span><div><h3>Check</h3><p>Run the project’s checks; use failures to guide corrections.</p></div></li>
<li><span>05</span><div><h3>Review</h3><p>Inspect the implementation and evidence. Return anything that needs work.</p></div></li>
<li><span>06</span><div><h3>My review</h3><p>I inspect the result and decide whether to merge the pull request.</p></div></li>
</ol>
<dl class="delivery-strip"><div><dt>Local checks</dt><dd>Verify the working copy.</dd></div><div><dt>PR checks</dt><dd>Verify a fresh checkout in CI.</dd></div><div><dt>Release / deploy</dt><dd>A separate, deliberate action.</dd></div></dl></section>
<section id="projects"><div class="section-heading"><span class="eyebrow">02 · Project foundations</span><h2>The project gives agents their bearings</h2><p>I want an agent to find the relevant code and get useful feedback without loading a manual. I think about that in four layers:</p></div>
<figure class="project-layers"><dl>
<div><dt><span>01</span>Context</dt><dd><h3>Explain what the code cannot</h3><p>Short instructions point to the project’s purpose, decisions and non-obvious constraints. Detailed guidance loads when needed.</p><small>Guides judgement</small></dd></div>
<div><dt><span>02</span>Structure</dt><dd><h3>Make the project easy to navigate</h3><p>Clear module boundaries and consistent file roles keep related code and tests together.</p><small>Shapes the work</small></dd></div>
<div><dt><span>03</span>Checks</dt><dd><h3>Turn rules into feedback</h3><p>Formatters, types, tests and project rules produce failures an agent can act on.</p><small>Enforces the specific rules checked</small></dd></div>
<div><dt><span>04</span>Custody</dt><dd><h3>Keep the checks effective</h3><p>Test that custom rules catch violations. Review changes to guardrails; use required CI checks where configured.</p><small>Protects the checks</small></dd></div>
</dl><figcaption>Context and structure guide the work. A passing check establishes only what that check tests.</figcaption></figure>
<p>Typing, linting, formatting and complexity rules follow the project’s requirements. Some preferences carry across repositories, including limits on file and function length. The Makefile is the common command interface: <code>make format</code> applies the project’s formatting, and <code>make check</code> runs its full gate.</p>
@@TEST@@
</section>
<section id="team"><div class="section-heading"><span class="eyebrow">03 · Agent teams</span><h2>Keep the lead free to think</h2><p>For parallel work or independent review, I use <code>lead-team</code>. Each agent takes a bounded job, leaving the lead’s context available for planning and decisions.</p></div>{team_diagram}
<p>Each agent starts with its task contract and only the context it needs. Worker contracts define file ownership; tasks touching the same files run in sequence. A shared ledger records progress, and hooks check the handoffs.</p>
<div class="task-example" id="contract"><h3>From a contract to an accepted result</h3><dl class="handoff-grid"><div><dt>Contract</dt><dd>Set the goal, dependencies and evidence needed for acceptance.</dd></div><div><dt>Report</dt><dd>Hooks check the report’s structure and required evidence fields.</dd></div><div><dt>Acceptance</dt><dd>The lead reads the changes and evidence, then accepts or sends back.</dd></div></dl><div class="states" aria-label="Task state sequence"><span>queued</span><i>→</i><span>running</span><i>→</i><span>reported</span><i>→</i><span class="focus">accepted</span></div><p class="aside">Acceptance unlocks dependent tasks. A report that passes structural checks still needs judgement.</p></div>
@@HOOKS@@
@@MODELS@@
<div id="observer" class="team-observer"><h3>Seeing what the team is doing</h3><p>The observer is a read-only view of a run. Its graph shows dependencies and rework; an agent’s card shows context use, token counts, live messages and tool calls. Saved runs can be inspected offline.</p>
<figure class="dashboard-preview"><a href="team-workflow.jpg" aria-label="Open the workflow graph at full size"><img src="team-workflow.jpg" width="2400" height="1714" alt="Team observer workflow: parallel tasks converge on review, with the final check reported and packaging queued." loading="lazy"></a><figcaption>Parallel tasks converge on review. The purple final check awaits acceptance before packaging can begin. Tap for full size.</figcaption></figure>
@@AGENTCARD@@
</div></section>
<section id="environment"><div class="section-heading"><span class="eyebrow">04 · The workbench</span><h2>Work from anywhere</h2><p>T3 lets me direct Claude and Codex from a laptop or phone, including speech-to-text briefs. The agents run on a permanent VM on dedicated, always-on Proxmox hardware. Tailscale provides private access; TrueNAS supplies shared storage.</p></div>{env_diagram}
<details id="workbench-inside"><summary>Inside the workbench</summary>{inside_diagram}<p><code>llmtrim</code> is configured for lossless input compression. Rootless Docker runs build and test containers. Cloud tools provide logs, analytics and authorised test deployments; browser tools inspect the result.</p></details>
<details id="gateway-inside"><summary>Inside the lab-control gateway</summary><p>MCP is the interface agents use to call tools. The lab-control gateway checks resource limits and records ownership before calling Proxmox and TrueNAS. Appliance credentials remain in the gateway.</p>{gateway_diagram}<p>Agents can inspect, create, extend and release disposable guests and shared storage. Cleanup requires matching ownership markers. Guest firewall rules limit access to management services and unrelated LAN devices; the permanent workbench retains LAN and lab connections.</p></details>
</section>
<section id="toolkit"><div class="section-heading"><span class="eyebrow">05 · The toolkit</span><h2>Tools and repeatable procedures</h2><p><code>agent-toolkit</code> keeps my shared skills and hooks together; <code>workbench-infra</code> holds the workbench configuration and runbooks.</p></div>
<h3>Skills</h3><dl class="kit-grid">
<div><dt>investigate</dt><dd>Reproduce a problem, test its cause and verify the fix. Useful wherever diagnosis is needed.</dd></div>
<div><dt>triage</dt><dd>Review issues against the project’s scope and record a verdict with its triage labels.</dd></div>
<div><dt>pr-body</dt><dd>Write a pull-request description from the change and its verification evidence.</dd></div>
<div><dt>project-init / project-evolve</dt><dd>Establish a project’s foundations, then maintain its architecture and checks as it changes.</dd></div>
<div><dt>gcp</dt><dd>Inspect cloud services and logs; carry out authorised operations in the intended project.</dd></div>
<div><dt>workbench</dt><dd>Check and maintain the permanent VM using its current configuration and runbooks.</dd></div>
</dl><p class="skill-invocation">Agents can select skills such as <code>investigate</code> and <code>pr-body</code>. I explicitly request workflows such as <code>triage</code>, <code>project-init</code> and <code>lead-team</code>.</p>
@@INVOCATION@@
<h3>Tools and practices</h3><dl class="kit-grid">
<div><dt>GitHub</dt><dd>Issues for scope and evidence, labels for triage, pull requests for review.</dd></div>
<div><dt>Worktrees</dt><dd>Separate working copies for T3 coding threads and each writing agent. Read-only agents can share a checkout.</dd></div>
<div><dt>T3 + Claude / Codex</dt><dd>Direct coding agents from a browser and continue the session across devices.</dd></div>
<div><dt>Google Cloud + Cloudflare</dt><dd>Read production logs and analytics, and deploy test builds through authorised workflows.</dd></div>
</dl></section>
</main><footer><span>Andrew McDonald · Portfolio draft</span></footer>'''
for key,value in [('TEST',test),('HOOKS',hooks),('MODELS',models),('AGENTCARD',agentcard),('INVOCATION',invocation)]:body=body.replace('@@'+key+'@@',value)
head='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>How I work as a solo developer — Andrew McDonald</title><link rel="stylesheet" href="d-workflow.css"></head><body>'
prefix=s[:s.index("html=f'''")]
p.write_text(prefix+"html=f'''"+head+body+"</body></html>'''\n(out/'d-workflow.html').write_text(html)\nprint('Wrote revision21: workflow, project layers, teams, workbench, toolkit.')\n")
p=Path('/tmp/style-workflow-blog.py');s=p.read_text();assert 'column-20' in s;p.write_text(s.replace('column-20','column-21'))
css=root/'d-workflow.css'
css.write_text(css.read_text()+'''
/* Compact workflow, project layers and toolkit catalogue. */
.workflow .flow-grid, .workflow .kit-grid, .workflow .handoff-grid {
 display: grid; grid-template-columns: repeat(2,minmax(0,1fr)); gap: 0;
 border: 1px solid var(--rule); border-radius: .4rem; overflow: hidden;
 padding: 0; margin: 1.5rem 0; list-style: none;
}
.workflow .flow-grid li { display: flex; align-items: flex-start; gap: .8rem; padding: 1.15rem; margin: 0; border-bottom: 1px solid var(--rule); }
.workflow .flow-grid li:nth-child(odd), .workflow .kit-grid > div:nth-child(odd) { border-right: 1px solid var(--rule); }
.workflow .flow-grid li:nth-last-child(-n+2), .workflow .kit-grid > div:nth-last-child(-n+2) { border-bottom: 0; }
.workflow .flow-grid li > span { display: grid; place-items: center; flex: 0 0 1.65rem; height: 1.65rem; border-radius: 50%; background: var(--color-wash-1); color: var(--color-accent); font: 600 .73rem var(--font-ui); }
.workflow .flow-grid h3 { font-size: 1rem; margin: 0 0 .35rem; }
.workflow .flow-grid p, .workflow .kit-grid dd, .workflow .handoff-grid dd { margin: 0; font-size: .94rem; line-height: 1.55; }
.workflow .delivery-strip { display: grid; grid-template-columns: repeat(3,minmax(0,1fr)); gap: 1rem; margin: 1rem 0; }
.workflow .delivery-strip dt { font: 600 .8rem/1.5 var(--font-ui); }
.workflow .delivery-strip dd { font: .78rem/1.55 var(--font-ui); color: var(--color-muted); margin-top: .3rem; }
.workflow .project-layers { margin-block: 1.5rem; }
.workflow .project-layers dl { margin: 0; border: 1px solid var(--rule); border-radius: .4rem; overflow: hidden; }
.workflow .project-layers dl > div { display: grid; grid-template-columns: 8rem minmax(0,1fr); gap: 1.5rem; padding: 1.25rem; border-bottom: 1px solid var(--rule); }
.workflow .project-layers dl > div:last-child { border-bottom: 0; }
.workflow .project-layers dt { font: 600 1rem/1.5 var(--font-ui); }
.workflow .project-layers dt span { display: block; color: var(--color-accent); font-size: .75rem; margin-bottom: .3rem; }
.workflow .project-layers h3 { font-size: 1.05rem; margin: 0 0 .35rem; }
.workflow .project-layers p { font-size: .94rem; margin: 0; line-height: 1.6; }
.workflow .project-layers small { display: block; color: var(--color-muted); font: .72rem/1.5 var(--font-ui); margin-top: .5rem; }
.workflow .project-layers figcaption { margin-top: .7rem; }
.workflow .kit-grid > div, .workflow .handoff-grid > div { padding: 1rem 1.15rem; border-bottom: 1px solid var(--rule); }
.workflow .kit-grid dt, .workflow .handoff-grid dt { font: 600 .9rem/1.6 var(--font-ui); margin-bottom: .4rem; }
.workflow .handoff-grid { grid-template-columns: repeat(3,minmax(0,1fr)); }
.workflow .handoff-grid > div { border-bottom: 0; }
.workflow .handoff-grid > div + div { border-left: 1px solid var(--rule); }
.workflow .skill-invocation { font-size: .94rem; }
@media (max-width: 42rem) {
 .workflow .flow-grid li { display: block; padding: .85rem; }
 .workflow .flow-grid li > span { width: 1.6rem; margin-bottom: .6rem; }
 .workflow .flow-grid p { font-size: .87rem; }
 .workflow .project-layers dl > div { grid-template-columns: minmax(0,1fr); gap: .7rem; padding: 1rem; }
 .workflow .project-layers dt { display: flex; gap: .7rem; align-items: baseline; }
 .workflow .project-layers dt span { margin: 0; }
 .workflow .kit-grid, .workflow .handoff-grid { grid-template-columns: minmax(0,1fr); }
 .workflow .kit-grid > div:nth-child(odd) { border-right: 0; }
 .workflow .kit-grid > div:nth-last-child(2) { border-bottom: 1px solid var(--rule); }
 .workflow .handoff-grid > div + div { border-left: 0; border-top: 1px solid var(--rule); }
}
''')
# Freeze the earlier draft's CSS so comparisons remain faithful.
p=root/'d-revision20.html';p.write_text(p.read_text().replace('d-workflow.css?style=column-20','d-revision20.css'))

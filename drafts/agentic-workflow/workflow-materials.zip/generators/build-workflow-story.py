from pathlib import Path
from html import escape
import json
old=Path('/tmp/build-agentic-visual-mocks.py').read_text()
exec(old[:old.index('# V0:')])
out=Path('/home/andy/.t3/artifacts/agentic-workflow-20261009')
def diagram(wide,mobile,caption=''):
 return '<figure class="drawing"><div class="wide">'+wide+'</div><div class="mobile">'+mobile+'</div>'+('<figcaption>'+caption+'</figcaption>' if caption else '')+'</figure>'
exec(Path('/tmp/workflow-team-diagram.py').read_text())
# Context map. The named workbench and gateway are opened by the next views.
b=node(20,140,180,80,'My browser','Laptop or phone')
b+=box(270,20,500,345,'PROXMOX · runs the virtual machines')
b+=node(310,125,210,100,'AI workbench','T3 · Claude · Codex|Permanent VM','primary')
b+=node(555,235,180,85,'Test VM','Disposable guest')
b+=node(835,235,245,85,'TrueNAS','Temporary shared files')
b+=node(835,25,245,100,'Cloud services','Hosted models|Google Cloud · Cloudflare')
b+=wire('M200 180 H310','Tailscale',254,160)+wire('M520 165 H580 V75 H835','APIs',691,59)
b+=wire('M520 195 H545 V277 H555')+wire('M735 277 H835','NFS',784,260)
env=svg('story-env',1100,395,b,'Where the workflow runs','A browser reaches the permanent AI workbench through Tailscale. Proxmox runs the workbench and disposable test guest. TrueNAS provides temporary files to the guest. The workbench connects to hosted model APIs and cloud tools. The workbench box is expanded in the next view.')
b=node(65,10,300,75,'My browser','Private access through Tailscale')+box(20,140,390,380,'PROXMOX HOST','Dedicated hardware · always on')+node(65,205,300,100,'AI workbench','T3 · Claude · Codex|Permanent VM','primary')+node(65,390,300,85,'Test VM','Firewalled lab network')+node(65,585,300,85,'TrueNAS','Temporary shared files')
b+=wire('M215 85 V205')+wire('M215 305 V390')+wire('M215 475 V585','NFS files',273,559)
b+='<text class="muted" x="215" y="720" text-anchor="middle">Workbench → hosted models + cloud tools</text>'
env_m=svg('story-env-mobile',430,750,b,'Where the workflow runs','The Proxmox host contains a permanent workbench and disposable guest. The guest uses temporary TrueNAS storage; the workbench also reaches external model and cloud services.')
# Zoom 1. The permanent VM is opened; outside systems stay outside its frame.
b=box(20,20,715,420,'AI WORKBENCH · the permanent VM above')
b+=node(55,100,190,75,'T3 Code','Browser interface')+node(55,265,190,90,'Claude / Codex','Coding clients')
b+=node(410,95,285,75,'llmtrim','Local model-request proxy')+node(410,220,285,75,'Cloud tools','Google Cloud SDK · Cloudflare MCP')+node(410,345,285,75,'lab-control MCP','Open this gateway in Zoom 2','primary')
b+=node(825,95,245,75,'Hosted models','Model providers')+node(825,220,245,75,'Cloud services','Logs · analytics · test builds')+node(825,345,245,75,'Proxmox + TrueNAS','Guest + storage APIs')
b+=wire('M150 175 V265')+wire('M245 295 H310 V132 H410')+wire('M310 257 H410')+wire('M310 295 V382 H410')
b+=wire('M695 132 H825')+wire('M695 257 H825')+wire('M695 382 H825')
inside=svg('story-inside',1100,470,b,'Inside the AI workbench','T3 launches the coding clients. They reach hosted models through llmtrim, use cloud tools for service evidence and test deployments, and call lab-control for temporary machines and storage. Appliance services and hosted providers sit outside the workbench boundary.')
b=box(15,10,400,545,'AI WORKBENCH')+node(60,70,310,75,'T3 Code','Browser interface')+node(60,185,310,75,'Claude / Codex','Coding clients')+node(60,320,310,75,'llmtrim + cloud tools','Model APIs · SDK · MCP')+node(60,450,310,75,'lab-control MCP','Proxmox + TrueNAS tools','primary')
b+=wire('M215 145 V185')+wire('M215 260 V320')+wire('M60 225 H35 V487 H60')
b+='<text class="muted" x="215" y="600" text-anchor="middle">Providers and appliances remain outside this VM.</text>'
inside_m=svg('story-inside-mobile',430,630,b,'Inside the workbench','T3 launches Claude or Codex. llmtrim and cloud tools connect to providers; lab-control supplies bounded appliance operations.')
# Zoom 2: code behind one MCP tool call, not a new deployment map.
b=box(225,20,845,310,'INSIDE LAB-CONTROL')+node(20,110,165,85,'Agent','MCP request')+node(265,110,200,85,'Policy checks','Limits · expiry')+node(520,110,190,85,'Lease record','SQLite ownership')+node(815,45,240,85,'Proxmox adapter','Create / release guest')+node(815,220,240,85,'TrueNAS adapter','Dataset + NFS storage')
b+=wire('M185 152 H265')+wire('M465 152 H520')+wire('M710 152 H775 V87 H815')+wire('M775 152 V262 H815')
gateway=svg('story-gateway',1080,340,b,'Inside lab-control','An MCP request enters code that checks policy and records a lease before the credentialed adapters call Proxmox and TrueNAS. This view opens the lab-control box from the workbench diagram.')
b=node(65,10,300,75,'Agent','MCP request')+box(20,125,390,475,'INSIDE LAB-CONTROL')+node(65,185,300,75,'Policy checks','Resource limits · expiry')+node(65,300,300,75,'Lease record','SQLite ownership')+node(65,475,300,95,'Credentialed adapters','Proxmox guest|TrueNAS dataset + NFS')
b+=wire('M215 85 V185')+wire('M215 260 V300')+wire('M215 375 V475')
gateway_m=svg('story-gateway-mobile',430,625,b,'Inside lab-control','MCP requests pass through policy and a recorded lease to the Proxmox and TrueNAS adapters.')
contract=json.loads((out/'contract-example-check.json').read_text())
json_contract=escape(json.dumps(contract['contract'],indent=2))
team_diagram=diagram(team,team_m,'The lead selects the roles needed. Task dependencies determine execution order.')
env_diagram=diagram(env,env_m,'The workbench stays available when I switch devices. Disposable test VMs use a separate lab network, with firewall rules restricting access to the rest of the LAN.')
inside_diagram=diagram(inside,inside_m)
gateway_diagram=diagram(gateway,gateway_m)
html=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>How I work as a solo developer — Andrew McDonald</title><link rel="stylesheet" href="d-workflow.css"></head><body><header><a href="index.html">Andrew McDonald</a><span>Portfolio draft</span><a href="sources.html">Source notes</a></header>
<main><div class="hero"><span class="eyebrow">Solo development · Agentic engineering</span><h1>How I work as a solo developer</h1><p class="intro">I use Claude and Codex across my projects, often moving between different languages and frameworks. I give capable models a clear outcome and room to work out the implementation, with the repository providing the checks and constraints that fit the project.</p><p>A lot of the setup comes down to deciding what needs judgement and what can be checked in code. Here’s how that fits together, from a single coding session to a team working in parallel.</p></div>
<nav aria-label="On this page"><a href="#workflow">Workflow</a><a href="#projects">Project layers</a><a href="#team">Agent team</a><a href="#environment">Workbench</a><a href="#toolkit">Toolkit</a></nav>
<section id="workflow"><div class="section-heading"><span class="eyebrow">01 · The workflow</span><h2>From idea to merge</h2><p>The amount of planning depends on the change. A small fix can go straight to implementation.</p></div>
<ol class="flow-grid">
<li><span>01</span><div><h3>Brief</h3><p>Scope and acceptance criteria, usually in a GitHub issue.</p></div></li>
<li><span>02</span><div><h3>Plan</h3><p>Choose the approach and divide the work where useful.</p></div></li>
<li><span>03</span><div><h3>Build</h3><p>Implement in an isolated worktree, with tests for the behaviour.</p></div></li>
<li><span>04</span><div><h3>Check</h3><p>Run the project’s checks; use failures to guide corrections.</p></div></li>
<li><span>05</span><div><h3>Review</h3><p>Inspect the implementation and evidence. Return anything that needs work.</p></div></li>
<li><span>06</span><div><h3>My review</h3><p>I inspect the result and decide whether to merge the pull request.</p></div></li>
</ol>
<dl class="delivery-strip"><div><dt>Local checks</dt><dd>Verify the working copy.</dd></div><div><dt>PR checks</dt><dd>Verify a fresh checkout in CI.</dd></div><div><dt>Release / deploy</dt><dd>A separate, deliberate action.</dd></div></dl></section>
<section id="projects"><div class="section-heading"><span class="eyebrow">02 · Project foundations</span><h2>The project gives agents their bearings</h2><p>I want an agent to find the relevant code and get useful feedback without loading a manual. I think about that in four layers:</p></div>
<figure class="project-layers"><dl>
<div><dt><span>01</span>Context</dt><dd><h3>Explain what the code cannot</h3><p>Short instructions point to the project’s purpose, decisions and non-obvious constraints. Detailed guidance loads when needed.</p></dd></div>
<div><dt><span>02</span>Structure</dt><dd><h3>Make the project easy to navigate</h3><p>Clear module boundaries and consistent file roles keep related code and tests together.</p></dd></div>
<div><dt><span>03</span>Checks</dt><dd><h3>Turn rules into feedback</h3><p>Formatters, types, tests and project rules produce failures an agent can act on.</p></dd></div>
<div><dt><span>04</span>Custody</dt><dd><h3>Keep the checks effective</h3><p>Test that custom rules catch violations. Review changes to guardrails; use required CI checks where configured.</p></dd></div>
</dl><figcaption>Context and structure guide the work. A passing check establishes only what that check tests.</figcaption></figure>
<p>Typing, linting, formatting and complexity rules follow the project’s requirements. Some preferences carry across repositories, including limits on file and function length. The Makefile is the common command interface: <code>make format</code> applies the project’s formatting, and <code>make check</code> runs its full gate.</p>
<div class="test"><h3>Tests a person can read</h3><p>Given–When–Then comments describe the starting state, action and expected result.</p><pre>it("rounds 201 words up to two minutes", () =&gt; {{
  // Given a Markdown body with 201 words.
  const body = Array(201).fill("word").join(" ");

  // When its reading time is estimated.
  const minutes = readingMinutes(body);

  // Then the estimate is two minutes.
  expect(minutes).toBe(2);
}});</pre><p class="aside">This blog’s test catches rounding down at the 200-word boundary.</p></div>
</section>
<section id="team"><div class="section-heading"><span class="eyebrow">03 · Agent teams</span><h2>Keep the lead free to think</h2><p>For parallel work or independent review, I use <code>lead-team</code>. Each agent takes a bounded job, leaving the lead’s context available for planning and decisions.</p></div>{team_diagram}
<p>Each agent starts with its task contract and only the context it needs. Worker contracts define file ownership; tasks touching the same files run in sequence. A shared ledger records progress, and hooks check the handoffs.</p>
<div class="task-example" id="contract"><h3>From a contract to an accepted result</h3><dl class="handoff-grid"><div><dt>Contract</dt><dd>Set the goal, dependencies and evidence needed for acceptance.</dd></div><div><dt>Report</dt><dd>Hooks check the report’s structure and required evidence fields.</dd></div><div><dt>Acceptance</dt><dd>The lead reads the changes and evidence, then accepts or sends back.</dd></div></dl><div class="states" aria-label="Task state sequence"><span>queued</span><i>→</i><span>running</span><i>→</i><span>reported</span><i>→</i><span class="focus">accepted</span></div><p class="aside">Acceptance unlocks dependent tasks. A report that passes structural checks still needs judgement.</p></div>
<details><summary>The six hooks and their limits</summary><p>The contract schema checks field names and types. Hooks check reports against the contract’s acceptance criteria.</p><dl class="tools"><div><dt>Spawn + start</dt><dd>Require a queued contract, accepted dependencies, the contract’s model or another in its recognised tier, and a permitted parent; bind the agent to its task.</dd></div><div><dt>Stop</dt><dd>Check report fields, criterion IDs and quoted commands; check Worker changes against file ownership.</dd></div><div><dt>Message</dt><dd>Require a recorded send-back before resuming a reported task.</dd></div><div><dt>Edit + shell</dt><dd>Reject the lead’s edits through covered tools and its polling sleeps, keeping implementation and waiting with task agents.</dd></div></dl><p>The stop hook blocks a malformed report once where the runtime permits it; repeated problems are recorded for the lead. Coverage depends on the runtime; hook errors and timeouts can allow an action. Hooks are not a security sandbox.</p></details>
<details><summary>Task context and model choice</summary><p>Planner and Reviewer tasks use stronger models, Worker and Explorer tasks use the middle tier, and Chores use the smallest tier. No member runs above the lead’s model tier. The user chooses review depth; focused Explorer tasks probe different risks. Workers implement fixes, and Chores run commands and report results.</p></details>
<div id="observer" class="team-observer"><h3>Seeing what the team is doing</h3><p>The observer is a read-only view of a run. Its graph shows dependencies and rework; an agent’s card shows context use, token counts, live messages and tool calls. Saved runs can be inspected offline.</p>
<figure class="dashboard-preview"><a href="team-workflow.jpg" aria-label="Open the workflow graph at full size"><img src="team-workflow.jpg" width="2400" height="1714" alt="Team observer workflow: parallel tasks converge on review, with the final check reported and packaging queued." loading="lazy"></a><figcaption>Parallel tasks converge on review. The purple final check awaits acceptance before packaging can begin. Tap for full size.</figcaption></figure>
<details><summary>Inspect an agent’s context and activity</summary><figure class="full-dashboard"><a href="observer-agent-desktop.png" aria-label="Open the lead agent card at full size"><picture><source media="(max-width: 42rem)" srcset="observer-agent-mobile.png"><img src="observer-agent-desktop.png" width="1606" height="1890" alt="Selected lead agent: model, context-window usage, input and output tokens, messages and recorded tool calls." loading="lazy"></picture></a><figcaption>The lead agent in a separate demonstration run, captured from the updated observer. Tap for the full-size card and expanded tool call.</figcaption></figure></details>
</div></section>
<section id="environment"><div class="section-heading"><span class="eyebrow">04 · The workbench</span><h2>Work from anywhere</h2><p>T3 lets me direct Claude and Codex from a laptop or phone, including speech-to-text briefs. The agents run on a permanent VM on dedicated, always-on Proxmox hardware. Tailscale provides private access; TrueNAS supplies shared storage.</p></div>{env_diagram}
<details id="workbench-inside"><summary>Inside the workbench</summary>{inside_diagram}<p><code>llmtrim</code> is configured for lossless input compression. Rootless Docker runs build and test containers. Cloud tools provide logs, analytics and authorised test deployments; browser tools inspect the result.</p></details>
<details id="gateway-inside"><summary>Inside the lab-control gateway</summary><p>MCP is the interface agents use to call tools. The lab-control gateway checks resource limits and records ownership before calling Proxmox and TrueNAS. Appliance credentials remain in the gateway.</p>{gateway_diagram}<p>Agents can inspect, create, extend and release disposable guests and shared storage. Cleanup requires matching ownership markers. Guest firewall rules limit access to management services and unrelated LAN devices; the permanent workbench retains LAN and lab connections.</p></details>
</section>
<section id="toolkit"><div class="section-heading"><span class="eyebrow">05 · The toolkit</span><h2>Tools and repeatable procedures</h2><p><code>agent-toolkit</code> keeps my shared skills and hooks together; <code>workbench-infra</code> holds the workbench configuration and runbooks.</p></div>
<h3>Skills</h3><dl class="kit-grid">
<div><dt>investigate</dt><dd>Reproduce a problem, test its cause and verify the fix. Useful wherever diagnosis is needed.</dd></div>
<div><dt>triage</dt><dd>Review issues against the project’s scope and record a verdict with its triage labels.</dd></div>
<div><dt>pr-body</dt><dd>Write a pull-request description from the change and its verification evidence.</dd></div>
<div><dt>project-init / project-evolve</dt><dd>Establish a project’s foundations, then maintain its architecture and checks as it changes.</dd></div>
<div><dt>gcp</dt><dd>Inspect cloud services and logs; carry out authorised operations in the intended project.</dd></div>
<div><dt>workbench</dt><dd>Check and maintain the permanent VM using its current configuration and runbooks.</dd></div>
</dl><p class="skill-invocation">Agents can select skills such as <code>investigate</code> and <code>pr-body</code>. I explicitly request workflows such as <code>triage</code>, <code>project-init</code> and <code>lead-team</code>.</p>
<details><summary>The two invocation settings</summary><p>Explicit-only skills set <code>disable-model-invocation: true</code> for Claude and <code>policy.allow_implicit_invocation: false</code> in <code>agents/openai.yaml</code> for Codex. A validator checks that both declarations agree. Skill selection is separate from permission to perform its actions.</p></details>
<h3>Tools and practices</h3><dl class="kit-grid">
<div><dt>GitHub</dt><dd>Issues for scope and evidence, labels for triage, pull requests for review.</dd></div>
<div><dt>Worktrees</dt><dd>Separate working copies for T3 coding threads and each writing agent. Read-only agents can share a checkout.</dd></div>
<div><dt>T3 + Claude / Codex</dt><dd>Direct coding agents from a browser and continue the session across devices.</dd></div>
<div><dt>Google Cloud + Cloudflare</dt><dd>Read production logs and analytics, and deploy test builds through authorised workflows.</dd></div>
</dl></section>
</main><footer><span>Andrew McDonald · Portfolio draft</span></footer></body></html>'''
(out/'d-workflow.html').write_text(html)
print('Wrote revision21: workflow, project layers, teams, workbench, toolkit.')

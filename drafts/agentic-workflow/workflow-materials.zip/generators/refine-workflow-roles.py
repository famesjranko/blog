from pathlib import Path
import re
p=Path('/tmp/build-workflow-story.py');s=p.read_text()
start=s.index('# Lead decisions')
end=s.index('# Context map.')
s=s[:start]+"exec(Path('/tmp/workflow-team-diagram.py').read_text())\n"+s[end:]
a="These arrows show who decides and reports. Task dependencies are stored separately: work starts only after its required results have been accepted."
b="These are available roles, not a fixed five-agent team or a sequence of steps. The lead selects the roles needed. Task dependencies determine when each can start."
assert a in s;s=s.replace(a,b)
a='<div class="model-strip"><p><b>Stronger models</b>Planning and independent review.</p><p><b>Mid-tier models</b>Implementation and focused exploration.</p><p><b>Smallest models</b>Named checks and routine tool work.</p></div>'
b='''<div class="review-check"><div><h3>Review · judgement</h3><p>A Reviewer assesses whether the integrated change meets the requirements. Explorers can probe specific risks, such as malformed input or failure paths.</p></div><div><h3>Checks · execution</h3><p>A Chore agent runs named commands and records their output. The tools determine pass or fail; the lead decides whether the evidence is sufficient to accept the task.</p></div></div>
<div class="model-strip"><p><b>Stronger models</b>Planner · Reviewer</p><p><b>Mid-tier models</b>Worker · Explorer</p><p><b>Smallest models</b>Chore</p></div>
<details><summary>How I choose the review work</summary><p>Team reviews normally use separate Explorer tasks, each looking for a different kind of defect. The user chooses the review depth; a lighter diff review can use a Reviewer where independent judgement helps. Findings return to the lead. Workers make fixes, fresh tasks recheck them, and a Chore runs the final checks after the required results are accepted.</p></details>'''
assert a in s;s=s.replace(a,b)
p.write_text(s)
p=Path('/tmp/style-workflow-blog.py');s=p.read_text()
start=s.index("b = node(210,15,280,85,'Lead'")
end=s.index("b = node(20,15,205,85,'My browser'")
s=s[:start]+s[end:]
s=s.replace("[('story-team',team),('story-env',env)","[('story-env',env)")
p.write_text(s)
p=Path('/home/andy/.t3/artifacts/agentic-workflow-20261009/d-workflow.css');s=p.read_text()
s=s.replace('/* Prototype layout only. Fonts, palette, reading measure and shell come from the blog. */', '/* Prototype layout: blog fonts and tokens, with more room for architectural figures. */')
s += '''
/* This portfolio format keeps prose narrow while opening up the visual explanations. */
.workflow { max-width: none; }
.workflow > *, .workflow section > * { max-width: var(--prose-width); margin-inline: auto; }
.workflow > section, .workflow .task-example, .workflow .evidence { max-width: none; }
.workflow .section-heading, .workflow .task-example > .aside { max-width: var(--prose-width); margin-inline: auto; }
.workflow #team > .drawing { max-width: none; }
.workflow #environment > .drawing, .workflow #workbench-inside, .workflow #gateway-inside { max-width: 58rem; }
.workflow #team > .drawing .wide .heading { font-size: 20px; }
.workflow #team > .drawing .wide .muted { font-size: 15px; }
.workflow .task-example > details, .workflow .evidence > details { max-width: var(--prose-width); margin-inline: auto; }
.workflow .task-example > .states { justify-content: center; }
.workflow .rejection, .workflow .real-decision { max-width: var(--prose-width); margin-inline: auto; }
.workflow .review-check { display: grid; grid-template-columns: repeat(2,minmax(0,1fr)); gap: 2rem; max-width: none; margin-block: 2rem; }
.workflow .review-check > div { padding-top: 1rem; border-top: 2px solid var(--color-accent); }
.workflow .review-check h3 { margin: 0 0 .7rem; font: 600 1rem/1.5 var(--font-ui); }
.workflow .review-check p { margin: 0; font-size: 1rem; }
.workflow .model-strip { max-width: none; }
@media (max-width: 42rem) {
 .workflow .review-check { grid-template-columns: minmax(0,1fr); gap: 1.25rem; }
 .workflow #team > .drawing { padding-inline: 0; }
}
'''
p.write_text(s)
p=Path('/home/andy/.t3/artifacts/agentic-workflow-20261009/sources.html');s=p.read_text()
new='''<h2>Separate roles and content-led styling</h2><p>Andy authorised departures from essay/project styling where the content benefits. The revised mock retains the blog shell, fonts and colour tokens. Prose keeps its 65ch measure; the team map, infrastructure views and paired evidence panels have more width. This is a deliberate portfolio-layout variation, still outside the real blog source.</p><p>Read current origin/main skills/lead-team/SKILL.md §§1, 3–9, references/models.md and references/verification.md. The earlier “Review + check” box grouped distinct responsibilities too loosely. The role map now explicitly separates Planner, Explorer, Worker, Reviewer and Chore. All report to the lead; it is not an execution sequence or a fixed team size. Reviewer is independent judgement; Chore runs specified checks; Explorer includes focused risk probes. Lens passes are the default team review, with the user choosing depth. The lead accepts evidence and dependencies gate starts. The map does not imply that every job creates all five roles or runs five agents concurrently.</p>'''
assert '<h2>Separate roles and content-led styling</h2>' not in s
s=s.replace('<h2>Deliberate editorial choices</h2>',new+'<h2>Deliberate editorial choices</h2>');p.write_text(s)

from pathlib import Path
p=Path('/tmp/build-workflow-story.py')
s=p.read_text()
s=s.replace('Workers use separate worktrees; file ownership and dependencies control which tasks can run together.', 'Each agent that edits code gets its own Git worktree: a separate working copy. Its contract names the files it owns and those it must not change. Tasks that need the same files run in sequence; independent tasks can run in parallel.')
s=s.replace('Select a task to inspect its contract, evidence and acceptance history. The ledger supplies task state; runtime logs supply activity. Saved runs can be inspected offline.', 'Select a task to inspect its contract and acceptance history, or an agent to see its model, context usage, token counts, live messages and tool calls. Saved runs can be inspected offline.')
old='<details><summary>Expand the full observer dashboard</summary><figure class="full-dashboard"><a href="team-dashboard.jpg" aria-label="Open the complete observer screenshot at full size"><img src="team-dashboard.jpg" width="1200" height="4132" alt="Full observer dashboard with attention panel, running tasks, workflow graph, contract, decision history, activity and team roles." loading="lazy"></a><figcaption>The full dashboard from the same run. Tap to inspect it at full size.</figcaption></figure></details>'
new='<details><summary>Inspect an agent’s context and activity</summary><figure class="full-dashboard"><a href="observer-agent-desktop.png" aria-label="Open the lead agent card at full size"><picture><source media="(max-width: 42rem)" srcset="observer-agent-mobile.png"><img src="observer-agent-desktop.png" width="1606" height="1890" alt="Selected lead agent: model, context-window usage, input and output tokens, messages and recorded tool calls." loading="lazy"></picture></a><figcaption>The lead agent in a separate demonstration run, captured from the updated observer. Tap for the full-size card and expanded tool call.</figcaption></figure></details>'
assert old in s
p.write_text(s.replace(old,new))
p=Path('/tmp/style-workflow-blog.py')
p.write_text(p.read_text().replace('column-17','column-18'))
p=Path('/tmp/capture-observer-agent.cjs')
s=p.read_text().replace("[['desktop',1440,1200],['mobile',430,1000]]", "[['mobile',430,1000]]").replace('await call.click();','')
Path('/tmp/capture-observer-mobile.cjs').write_text(s)

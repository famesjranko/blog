from pathlib import Path
import re
p=Path('/tmp/build-workflow-story.py')
s=p.read_text()
Path('/tmp/build-workflow-story-revision14.py').write_text(s)
out=Path('/home/andy/.t3/artifacts/agentic-workflow-20261009')
(out/'d-revision14.html').write_text((out/'d-workflow.html').read_text())

def replace(old,new):
    global s
    assert old in s, old[:100]
    s=s.replace(old,new,1)

replace('<p class="ownership">My <code>agent-toolkit</code> defines the roles, contracts, hooks and observer. <code>workbench-infra</code> connects the coding tools to a private workspace and disposable test lab.</p>','')
replace('<nav aria-label="On this page"><a href="#workflow">The workflow</a><a href="#team">The agent team</a><a href="#observer">The dashboard</a><a href="#environment">The workbench</a><a href="#checks">Repository checks</a></nav>','<nav aria-label="On this page"><a href="#workflow">How I work</a><a href="#checks">Engineering practices</a><a href="#team">Working with a team</a><a href="#environment">The workbench</a></nav>')
replace('01 · The workflow','01 · How I work')
replace('<p class="aside">I use <em>progressive disclosure</em>: start with the project’s entry instructions, then load the relevant code, tests and specialised guidance as the task needs them. A fresh task gets a fresh conversation.</p>','')
replace('Triage labels and investigation before a fix','How I triage issues')
old='<p>For a non-trivial bug, <code>investigate</code> starts with a reproduction and a testable explanation of the cause. The agent tests that explanation before changing code, then proves the fix with a regression test that fails without it and passes with it. An unconfirmed cause stays unresolved.</p>'
replace(old,'')
replace('</ol><details><summary>How I triage issues', '</ol><h3>Investigate before changing code</h3><p>Unexpected behaviour can appear during implementation, testing, review or maintenance. The <code>investigate</code> skill gives the agent a repeatable process: reproduce the problem, test an explanation of its cause, then verify the fix. A regression test must fail without the fix and pass with it; an unconfirmed cause stays unresolved.</p><details><summary>How I triage issues')
replace('05 · Inside “Review + check”','02 · Engineering practices')
replace('<p class="section-followup">The <code>make check</code> named in a task contract is the same gate used by people, agents and CI.', '<p class="section-followup">People, agents and CI use the same <code>make check</code> gate.')
replace('<div class="commands">','<p>I use <em>progressive disclosure</em>: start with the project’s entry instructions, then load the relevant code, tests and specialised guidance as the task needs them. A fresh task gets a fresh conversation.</p>\n<div class="commands">')
replace('02 · The team','03 · Working with a team')
replace('<h2>Keep the lead free to think</h2><p>My trials exposed unreliable handoffs:', '<h2>When a team earns its cost</h2><p>In three paired trials, teams took longer than single agents. Extra review caught defects on harder work, while the largest team run hit its time limit. I use a team when the additional review is worth its cost.</p><p>The lead plans the next move, judges results and integrates accepted work. Each task agent receives a contract and a fresh context containing only the material it needs. I built this coordination layer in <code>agent-toolkit</code>.</p><p>My trials exposed unreliable handoffs:')
replace('<p class="section-followup">The lead plans the next move, judges results and integrates accepted work. Each task agent receives a contract and a fresh context containing only the material it needs.</p>','')
replace('How I choose the review work','How I scope tasks and choose review work')
replace('</p></details>\n<details><summary>How I keep tasks small and context bounded</summary><p>The planner','</p><p>The planner')
# The worked example stays visible; full report syntax lives beside the schema.
report='''<pre>STATUS: DONE
CHANGED: none
EVIDENCE:
A1: `make check` → `exit 0`
NOT DONE: none
DECISIONS: none</pre>'''
replace(report,'<p>The agent reports that <code>make check</code> passed, but omits the commit it checked. The report addresses A1; it leaves A2 unanswered.</p>')
replace('The ledger stores accepted tasks as <code>done</code>.','')
replace('<div class="technical-pair"><pre>{json_contract}</pre><div>', '<div class="technical-pair"><pre>{json_contract}</pre><div><p>The incomplete report:</p>'+report+'<p>The ledger stores accepted tasks as <code>done</code>.</p>')
# Keep the observer visibly within the team section rather than a fifth category.
replace('</section>\n<section id="observer"><div class="section-heading"><span class="eyebrow">03 · Observe the team</span><h2>See what is happening, and what needs a decision</h2>', '<div id="observer" class="team-observer"><div class="section-heading"><h3>The team observer dashboard</h3>')
replace('Closing the observer saves a single-file replay that opens offline.</p></details></section>', 'Closing the observer saves a single-file replay that opens offline.</p></details></div></section>')
replace('The diagram shows the intended setup, including the disposable lab.', 'My <code>workbench-infra</code> repository defines this setup. The diagram shows its intended architecture, including the disposable lab.')
replace('MCP is the tool interface the agents call. One gateway provides six tools for Proxmox and TrueNAS:', 'The gateway exposes six MCP tools—operations an agent can call—for Proxmox and TrueNAS:')
replace('<div class="cloud-access"><h3>Use live evidence and test deployments</h3><dl class="tools">', '<div class="cloud-access"><p>Connected cloud and browser tools let agents inspect production logs and analytics, deploy authorised test builds and check the result.</p><details><summary>Cloud tools, test builds and their permissions</summary><dl class="tools">')
replace('</dd></div></dl><details><summary>Keep inspection and deployment permissions distinct</summary><p>The Cloudflare', '</dd></div></dl><p>The Cloudflare')
replace('<div class="closing"><h2>What testing the workflow taught me</h2><p>In three paired trials, teams took longer than single agents. Extra review caught defects on harder work, while the largest team run hit its time limit. I keep small changes with one agent and use a team when the additional review is worth its cost. The process has to earn its place as the models and my projects change.</p>', '<div class="closing"><p>The process has to earn its place as the models and my projects change. I keep small changes with one agent and add coordination where the work justifies it.</p>')
# Complete the ordinary single-agent path before opening the optional team.
start=s.index('<section id="checks">')
end=s.index('</section>',start)+len('</section>')
checks=s[start:end]
s=s[:start]+s[end:]
pos=s.index('<section id="team">')
s=s[:pos]+checks+'\n'+s[pos:]
p.write_text(s)
css=out/'d-workflow.css'
css.write_text(css.read_text()+'\n.workflow .team-observer { margin-top: 3rem; padding-top: 1.25rem; border-top: 1px solid var(--rule); }\n')
style=Path('/tmp/style-workflow-blog.py')
style.write_text(style.read_text().replace('column-14','column-15'))

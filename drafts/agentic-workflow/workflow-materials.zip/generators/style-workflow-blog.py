from pathlib import Path
import re
import shutil
import runpy

repo = Path('/home/andy/.t3/worktrees/blog/t3code-237e6154')
out = Path('/home/andy/.t3/artifacts/agentic-workflow-20261009')
if not (out / 'd-before-blog-style.html').exists():
    shutil.copy2(out / 'd-workflow.css', out / 'd-before-blog-style.css')
    old = (out / 'd-workflow.html').read_text().replace('d-workflow.css', 'd-before-blog-style.css')
    (out / 'd-before-blog-style.html').write_text(old)
runpy.run_path('/tmp/build-workflow-story.py')
assets = out / 'blog-style'
for folder in ['css', 'fonts', 'js']:
    (assets / folder).mkdir(parents=True, exist_ok=True)
for name in ['fonts', 'main', 'header', 'prose', 'figures', 'essay', 'diagrams']:
    shutil.copy2(repo / f'styles/{name}.css', assets / f'css/{name}.css')
for font in (repo / 'static/fonts').iterdir():
    shutil.copy2(font, assets / 'fonts' / font.name)
for name in ['theme', 'mobile-nav']:
    shutil.copy2(repo / f'dist/js/{name}.js', assets / f'js/{name}.js')
reference = (repo / 'dist/essays/kant-enlightenment/index.html').read_text()
header = re.search(r'<header class="site-header">.*?</header>', reference, re.S).group()
footer = re.search(r'<footer class="site-footer">.*?</footer>', reference, re.S).group()
header = re.sub(r'href="(/[^\"]*)"', r'href="https://andrewjmcdonald.com\1"', header)
footer = re.sub(r'href="(/[^\"]*)"', r'href="https://andrewjmcdonald.com\1"', footer)
boot = re.search(r'<script>.*?</script>', reference, re.S).group()
html = (out / 'd-workflow.html').read_text()
body = re.search(r'<main>(.*)</main>', html, re.S).group(1)
body = body.replace('<div class="hero"><span class="eyebrow">Solo development · Agentic engineering</span><h1>How I work as a solo developer</h1>', '<header class="article-heading"><p class="article-meta"><span class="draft-eyebrow">Draft</span> Solo development · Agentic engineering</p><h1>How I work as a solo developer</h1></header><div class="opening">', 1)
body = body.replace('<nav aria-label="On this page">', '<nav class="article-nav" aria-label="On this page">')
body = body.replace('M215 85 V205', 'M215 85 V115 H385 V255 H365').replace('M215 85 V185', 'M215 85 V110 H390 V222 H365')
body = body.replace('<details>', '<details class="editorial-note">').replace('<details id=', '<details class="editorial-note" id=')
body = body.replace('<details class="related-reading">', '<details class="editorial-note related-reading">')
# Compact landscape diagrams fit the site's reading measure without tiny labels.
g = {}
source = Path('/tmp/build-agentic-visual-mocks.py').read_text()
exec(source[:source.index('# V0:')], g)
node, box, wire, svg = (g[k] for k in ['node','box','wire','svg'])
b = node(20,15,205,85,'My browser','Laptop or phone') + box(20,160,410,310,'PROXMOX HOST','Dedicated hardware · always on')
b += node(60,220,310,100,'AI workbench','T3 · Claude · Codex|Permanent VM','primary') + node(60,370,310,75,'Test VM','Firewalled lab network')
b += node(465,220,225,100,'Cloud services','Hosted models|Google Cloud · Cloudflare') + node(465,370,225,75,'TrueNAS','Temporary shared files')
b += wire('M122 100 V125 H330 V220','Tailscale',222,112) + wire('M370 270 H465','APIs',418,250) + wire('M215 320 V370') + wire('M370 408 H465','NFS',418,391)
env = svg('blog-env',710,495,b,'Where the workflow runs','A browser reaches the permanent workbench through Tailscale. Dedicated, always-on hardware runs Proxmox. The permanent workbench calls cloud services; disposable test virtual machines use a firewalled lab network and temporary TrueNAS storage.')
b = box(15,15,425,510,'AI WORKBENCH') + node(45,80,155,75,'T3 Code','Browser UI') + node(230,80,185,75,'Claude / Codex','Coding clients')
b += node(90,235,310,75,'llmtrim','Lossless input compression') + node(90,355,310,75,'Cloud tools','Google SDK · Cloudflare MCP') + node(90,455,310,60,'lab-control MCP','','primary')
b += node(475,235,215,75,'Hosted models','Model providers') + node(475,355,215,75,'Cloud services','Logs · test builds') + node(475,455,215,60,'Proxmox + TrueNAS')
b += wire('M200 117 H230') + wire('M323 155 V200 H50 V485 H90') + wire('M50 273 H90') + wire('M50 393 H90') + wire('M400 273 H475') + wire('M400 393 H475') + wire('M400 485 H475')
inside = svg('blog-inside',710,550,b,'Inside the AI workbench','T3 launches coding clients. Their calls reach model providers via llmtrim, cloud services via cloud tools, and the lab appliances via lab-control. The provider and appliance boxes are outside the VM.')
b = node(215,10,280,75,'Agent','MCP request') + box(20,135,670,335,'INSIDE LAB-CONTROL')
b += node(65,195,260,80,'Policy checks','Resource limits · expiry') + node(385,195,260,80,'Lease record','SQLite ownership')
b += node(65,365,260,80,'Proxmox adapter','Create / release guest') + node(385,365,260,80,'TrueNAS adapter','Dataset + NFS storage')
b += wire('M355 85 V115 H290 V195') + wire('M325 235 H385') + wire('M515 275 V365') + wire('M515 275 V315 H195 V365')
gateway = svg('blog-gateway',710,490,b,'Inside lab-control','Agent requests pass through policy checks and a recorded lease before credentialed Proxmox and TrueNAS adapters create or release resources.')
for old_id, replacement in [('story-env',env),('story-inside',inside),('story-gateway',gateway)]:
    pattern = r'<svg class="diagram"[^>]*aria-labelledby="' + old_id + r'-title [^\"]*".*?</svg>'
    body, count = re.subn(pattern, lambda m: replacement, body, flags=re.S)
    assert count == 1, (old_id,count)
links = ''.join(f'<link rel="stylesheet" href="blog-style/css/{name}.css">' for name in ['fonts','main','header','prose','figures','essay','diagrams'])
html = f'''<!doctype html><html lang="en"><head><meta charset="utf-8">{boot}<meta name="color-scheme" content="light dark"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>How I work as a solo developer — Andrew J. McDonald</title>{links}<link rel="stylesheet" href="d-workflow.css?style=column-21"><script src="blog-style/js/theme.js" defer></script><script src="blog-style/js/mobile-nav.js" defer></script></head><body><a class="skip-link" href="#main">Skip to content</a>{header}<main id="main"><div class="wrap"><article class="prose essay workflow">{body}<p class="draft-tools"><a href="sources.html">Draft source notes</a> · <a href="d-before-blog-style.html">Previous styling</a> · <a href="https://mattbalshaw.com/agentic-engineering">Inspired by Matt Balshaw’s workflow page</a></p></article></div></main>{footer}</body></html>'''
(out / 'd-workflow.html').write_text(html)
print('Applied the blog shell, stylesheet copies and reading-column diagrams.')

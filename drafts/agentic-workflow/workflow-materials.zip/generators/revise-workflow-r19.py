from pathlib import Path
from shutil import copyfile
root=Path('/home/andy/.t3/artifacts/agentic-workflow-20261009')
copyfile(root/'d-workflow.html',root/'d-revision18.html')
p=Path('/tmp/build-workflow-story.py')
s=p.read_text()
changes=[
('Project instructions preserve the constraints and decisions that the code cannot explain.</p></div>', '</p><p>I built the task contracts, coordination hooks and observer dashboard described below. I run them with Claude and Codex on an always-on workbench configured around T3.</p></div>'),
('<h3>Skills and explicit workflows</h3><p>My <code>agent-toolkit</code> packages procedures as skills.', '<p>I isolate changes with Git worktrees: separate working copies of a repository. I use T3’s worktree mode for coding threads; in teams, each agent that writes files gets its own. Read-only agents can inspect an existing checkout.</p>\n<h3>Skills and explicit workflows</h3><p>I maintain <code>agent-toolkit</code> as a shared library of skills for Claude and Codex.'),
(' Their metadata disables implicit invocation in Claude and Codex; a validator checks that both declarations agree.', ''),
('for Codex. Skill selection is separate', 'for Codex. A validator checks that both declarations agree. Skill selection is separate'),
('<p class="aside">The stages have different coverage. MusicMeta’s CI currently omits demo linting that runs locally; that gap is tracked separately.</p>', ''),
('My <code>lead-team</code> workflow assigns each agent a bounded task and only the context it needs. The lead coordinates the task graph, makes decisions and accepts results. Each agent that edits code gets its own Git worktree: a separate working copy. Its contract names the files it owns and those it must not change.', 'I designed <code>lead-team</code> to assign bounded tasks with only the context each agent needs. Delegating implementation and routine checks preserves the lead’s context for decisions. The lead coordinates the task graph and accepts results.</p><p>Each task contract names the files its agent owns and those it must not change.'),
('accepted dependencies, the assigned model and a permitted parent', 'accepted dependencies, the contract’s model or another in its recognised tier, and a permitted parent'),
('Coverage depends on the runtime. Hooks are not a security sandbox.', 'Coverage depends on the runtime; hook errors and timeouts can allow an action. Hooks are not a security sandbox.'),
('A real run: parallel tasks, dependencies and rework. Tap the graph for full size.', 'In this run, parallel tasks converge on review. The purple final check awaits acceptance before packaging can begin. Tap the graph for full size.'),
('The lab-control gateway checks resource limits and records ownership before calling Proxmox and TrueNAS; appliance credentials remain in the gateway.', 'I built the lab-control gateway to check resource limits and record ownership before calling Proxmox and TrueNAS. Appliance credentials remain in the gateway.')
]
for old,new in changes:
 assert s.count(old)==1,(old,s.count(old))
 s=s.replace(old,new)
s=s.replace('repeatable rules. </p>','repeatable rules.</p>')
p.write_text(s)
p=Path('/tmp/style-workflow-blog.py')
s=p.read_text()
assert 'column-18' in s
p.write_text(s.replace('column-18','column-19'))
